# BilBud
AI accounts-payable agent that reads vendor invoices, checks them against deterministic rules, and pays via PayPal Payouts, escalating or rejecting anything risky. Built for the PayPal AI Hackathon.
