# Quorum

Quorum is the settlement desk for teams who get paid as one. A client pays the studio a single amount.

A settlement desk for teams paid as one: rule-based code proposes a cent-exact split and a person approves it before any payment step. Demo runs on a local PayPal mock.

By default, Quorum runs a labelled local mock: rule-based code (not AI) proposes the split, the mock simulates every PayPal call, and no money moves. With PayPal sandbox keys set, the same buttons call the PayPal sandbox. Quorum has not yet been run against the real sandbox.

This is an independent demo for the PayPal AI Hackathon. It is not affiliated with PayPal. PayPal is a trademark of PayPal, Inc.

## Who it is for

Freelance pods, student teams, and small studios of two to eight people who share one client payment. One steward approves money movement. Teammates can object. Rule-based code prepares the split and the PayPal requests. It cannot approve, capture, or pay out. In the local mock, no PayPal call leaves the machine.

The sample studio is fictional: Halide Studio, the client Lumen & Lark, and four people with `@example.com` addresses. Every amount in the sample is labelled as a fictional sample. The desk refuses any email that is not on `example.com`.

## Run it

```bash
git clone https://github.com/HONGKONGBALL/quorum.git paypal-app
cd paypal-app
python3 -m venv .venv
.venv/bin/pip install -r requirements.txt
.venv/bin/python -m quorum
```

Open http://127.0.0.1:8765

No PayPal keys and no AI key are required. With neither set, Quorum uses a labelled local PayPal mock, and rule-based code proposes the split. The first screen says which mode is active.

The header control sends `X-Quorum-Actor`. That header is a demo persona switch. It is not authentication. Do not expose this app on the public internet.

The SQLite file is created at `./data/quorum.db`. Reset the desk from the header, or delete that file.

Developer checks:

```bash
.venv/bin/pip install -r requirements-dev.txt
.venv/bin/pytest
```

Browser tests launch system Google Chrome through Playwright. They bind a second server to `127.0.0.1:8877`.

## Users

| Person | Role | What they can do |
| --- | --- | --- |
| Avery Lin | Steward, producer | Approve a split, create an order, capture, release payouts, open a retainer, add a fictional teammate |
| Maya Ortiz | Editor | View the job and file an objection |
| Jonah Hale | Cinematographer | View the job and file an objection |
| Priya Shah | Sound | View the job and file an objection |

The header control labelled “Viewing as” is a demo persona switch. It sends `X-Quorum-Actor`. It is not an account system and it is not authentication. The API still checks the persona: a collaborator who calls the money endpoints receives `403`. Do not expose this app on the public internet.

The steward can add a fictional teammate from the desk. The role is collaborator. The address has to be `@example.com`. The roster can grow from the four sample people. The product is for teams of two to eight.

## What a job does

By default (and in the demo video), steps 5–8 are simulated by the local mock and no money moves. With PayPal sandbox keys set, they call the PayPal sandbox instead.

1. The steward opens a job, or loads the Halide sample. The sample is the October brand film for $4,800.00, split by logged hours.
2. Rule-based code proposes shares in integer cents. The lines tie to the job amount. The desk shows the rationale and the trace.
3. A plain instruction such as “Move $400 from Avery to Maya” is applied to the policy baseline. Repeating it does not move the money again. A new proposal clears the previous approval. Decimal amounts stay intact: “Give Maya an extra $12.50”, “Move $400.50 from Avery to Maya”, and “Set Maya to 40.5%”. A sentence splitter does not cut on a decimal point that is part of a number. If a fragment contains money or a percent and is not fully parsed, the whole instruction returns 422 and the stored proposal is unchanged. A following remark that has no money instruction does not block the money sentence. A teammate’s objection can be placed in the instruction box with “Use as instruction”. The steward submits it. If it is not a money instruction, the desk returns 422 and the previous proposal stays.
4. The steward approves. Until then, payouts are refused in the interface and by the API.
5. PayPal Orders v2 creates an order with `intent: CAPTURE` for the full client amount. Creating it twice returns the same open order.
6. The buyer approves or cancels. In the local mock, that page says it is not PayPal. Cancel does not mark the client paid. Capture is a separate steward action.
7. A Payouts batch is built with one item per person for the approved shares (simulated by the local mock by default; sandbox with keys). The items sum to the captured amount. A payout timeout leaves that payout UNKNOWN. Retry sends the stored PayPal-Request-Id and the stored sender_batch_id. It does not create a second active payout. The payout panel explains the UNKNOWN state in one line. A SUCCESS, PENDING, or PROCESSING batch is not sent again.
8. A retainer is a Catalog product, a monthly Billing plan, and a Subscription. The subscriber approves it. A retainer failure on the product step, the plan step, or the subscription step names that step, keeps PayPal's debug_id, stores the retainer as status error, and writes a ledger error. The retainer is not active.

The ledger records proposals, orders, captures, payouts, and subscriptions with a time, a mode, and an outcome.

## Architecture

```
browser  static/index.html + static/js/app.js
            |
            v
FastAPI  quorum/main.py          persona header, SPA, mock checkout pages
            |
            v
quorum/service.py               cents, approval gate, idempotency, ledger
            |                         |
            v                         v
quorum/paypal                   quorum/ai
  payloads.py   shared REST bodies
  mock.py       labelled local mock
  rest.py       sandbox Orders, Payouts, Catalogs, Billing
  factory.py    fails closed without keys
            |
            v
SQLite      integer cents, one active order, one active payout
```

Money is integer cents. Dollar strings are parsed without binary floating point. PayPal request bodies are built once and used by both the mock and the live adapter, including `PayPal-Request-Id`. A payout timeout leaves that payout UNKNOWN. Retry sends the stored PayPal-Request-Id and the stored sender_batch_id. It does not create a second active payout. The payout panel explains the UNKNOWN state in one line. A SUCCESS, PENDING, or PROCESSING batch is not sent again.

A PayPal Orders v2 capture decline is HTTP 422 with name UNPROCESSABLE_ENTITY and the reason in details[].issue. Quorum classifies INSTRUMENT_DECLINED, PAYER_CANNOT_PAY, and REDIRECT_PAYER_FOR_ALTERNATE_FUNDING as PAYPAL_DECLINED. The order stays approved, the job stays unpaid, the next capture uses a new idempotency key, and a links[] rel redirect URL is shown so the buyer can change funding source. A top-level name of INSTRUMENT_DECLINED or PAYER_CANNOT_PAY is still a decline. Other UNPROCESSABLE_ENTITY issues, including CARD_EXPIRED, stay errors.

Fault rehearsal shows the armed message only after the server confirms the injection. A refusal leaves the error banner visible and does not show the armed info banner. Outside local mock, the control the server would reject is disabled and the reason is visible. Sandbox disables PayPal fault controls with "PayPal faults are only available in local mock mode." Live AI disables the proposal fault control with "Proposal faults are only available when local rule-based code makes the proposal."

Rule-based code splits by hours or equally, using largest-remainder cents. Ties break by person id. Instructions it understands: split equally, split by hours, move an amount, give someone an extra amount, and set a percent. Anything else that looks like money is rejected and the previous proposal stays.

The live model is an OpenAI-compatible `POST {AI_BASE_URL}/chat/completions` call. Its JSON is accepted only when every person id is real and the cents tie. A bad sum is rejected. `AI_MODE=live` without a key does not silently fall back to local rule-based code. The optional live AI path is off by default. Quorum needs no keys of any kind by default, and judges do not need a paid key to run it.

`PAYPAL_MODE=sandbox` without both keys does not pretend an order was sent. The live PayPal hosts are refused unless `PAYPAL_ALLOW_LIVE=yes`.

## Environment

| Variable | Secret | Purpose |
| --- | --- | --- |
| `PAYPAL_MODE` | no | `auto` (default), `mock`, or `sandbox`. `auto` calls sandbox only when both PayPal keys are set. |
| `PAYPAL_CLIENT_ID` | yes | PayPal REST app client id. Never displayed. |
| `PAYPAL_CLIENT_SECRET` | yes | PayPal REST app secret. Never displayed. |
| `PAYPAL_API_BASE` | no | Defaults to `https://api-m.sandbox.paypal.com`. |
| `PAYPAL_ALLOW_LIVE` | no | Set to `yes` only to allow `api-m.paypal.com` or `api.paypal.com`. Leave unset. |
| `AI_MODE` | no | `auto` (default), `mock`, or `live`. `auto` calls a live model only when `AI_API_KEY` is set. |
| `AI_API_KEY` | no | Optional. Key for an OpenAI-compatible chat completions API. Never displayed. |
| `AI_BASE_URL` | no | Defaults to `https://api.openai.com/v1`. |
| `AI_MODEL` | no | Defaults to `gpt-4o-mini`. |
| `PUBLIC_BASE_URL` | no | Origin embedded in PayPal return URLs. Defaults to `http://127.0.0.1:8765`. |
| `QUORUM_DATA_DIR` | no | SQLite directory. Defaults to `./data`. |
| `QUORUM_HOST` | no | Bind host. Defaults to `127.0.0.1`. |
| `QUORUM_PORT` | no | Bind port. Defaults to `8765`. |
| `QUORUM_ACTION_DELAY_MS` | no | Optional pause before proposal, order, capture, payout, and retainer calls. Defaults to `0`. |

The status page lists these variables and shows each secret as “set” or “not set”. It never returns a secret value.

Sandbox keys, when you have them:

```bash
export PAYPAL_MODE=sandbox
export PAYPAL_CLIENT_ID=your-sandbox-client-id
export PAYPAL_CLIENT_SECRET=your-sandbox-secret
export PUBLIC_BASE_URL=http://127.0.0.1:8765
.venv/bin/python -m quorum
```

The buyer then leaves this machine for PayPal’s sandbox checkout. The order’s return URL is `/paypal/return` and the cancel URL is `/paypal/cancel`. Return looks up the local order by the PayPal token, GETs `/v2/checkout/orders/{id}`, and writes APPROVED only when that GET says APPROVED. Cancel voids the local order. A subscription return calls `get_subscription` and stores the status PayPal reports. Capture still requires APPROVED. `PAYER_ACTION_REQUIRED` stays in flight, including its payer-action link. In sandbox mode the buttons say “Open PayPal checkout” and “Open PayPal to approve the subscription”. In mock mode they say “Open the local mock checkout” and “Open the local mock subscriber page”.

The live-AI success path was not run. A real PayPal sandbox end-to-end was not run. `PAYPAL_CLIENT_ID` and `PAYPAL_CLIENT_SECRET` were absent when this candidate was packaged. Service tests that use `httpx.MockTransport` and PayPal-shaped responses are not that live run.

## Demo video

A 1080p English demo with burned-in captions is `paypal-demo-rc4-psyche15.mp4` (2:32, 152.40 s, sha256 `9b3df0c9b44a6da8a070e12bd9471895e4211d92c8c9bd11b2e8326e97671a65`), recorded in local mock mode with app code at tag `rc4-psyche15` (same `quorum/` and `static/` as `rc4-psyche19`), with the narration text later committed in `rc4-psyche16` (`scripts/narrate_bailian.py`), synthesized with qwen3-tts-flash before that commit. The older files (`paypal-demo-rc2.mp4`, `paypal-demo-rc2-psyche2.mp4`, `paypal-demo-rc3-psyche6.mp4`, and the copies in `review/rc2/` and `review/rc3/`) use the earlier mock wording; do not upload them. The video shows only the local mock: rule-based code (not AI) proposes the split, the mock simulates PayPal, and no money moves. The PayPal sandbox path is not shown in it. It is under three minutes and has no music. Narration is spoken. Captions match that narration and sit in a bottom band. `scripts/record_demo.py` shows the mock happy path: a successful payout and an ACTIVE retainer. It does not show an UNKNOWN payout retry, a named retainer step error, an Orders v2 redirect, or a rejected fault injection. Regenerate it with the app stopped and no PayPal or AI keys exported:

```bash
mkdir -p demo
.venv/bin/python scripts/record_demo.py --display :97 --out demo/paypal-demo-rerecord.mp4 --work-dir /tmp/quorum-demo-work
```

`--display` picks the Xvfb display, `--out` the new mp4, and `--work-dir` the scratch folder for raw video, captions, narration, and data. The recorder refuses to overwrite any existing file or a protected older video.

## License

MIT. Copyright (c) 2026 Psyche. See [LICENSE](LICENSE).

The Fraunces and Outfit font files under `static/fonts/` are under the SIL Open Font License. See the `OFL-*.txt` files beside them.
