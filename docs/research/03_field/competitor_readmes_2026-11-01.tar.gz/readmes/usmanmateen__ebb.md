# Ebb

**A household flexibility market run by AI agents, settled instantly with PayPal Payouts.**

Every home on a street gets its own AI agent. When Britain's grid needs homes to use less electricity at peak (or more when there's surplus wind and sun), the agents bid, a deterministic auction buys the cheapest flexibility, smart-meter data checks who actually delivered, and the homes that did are paid through PayPal in the same minute. Homes that didn't get £0 and a plain-English reason.

Built for the PayPal AI Hackathon.

![Ebb control room after a turn-down event: 12 homes paid via PayPal sandbox, 12 Elm Street unpaid because its oven went on](docs/control-room.png)

> **Hosted demo:** _add Render URL_ · **Video:** _add link_ · **Run it yourself in 2 minutes:** [Quick start](#quick-start)

---

## The problem

Britain's grid operator (NESO) already pays households to shift electricity use, through suppliers and aggregators (the Demand Flexibility Service). Today that means: an alert arrives, a person has to notice it and react by hand, and the reward is points or a bill credit weeks later. Participation is low because it's effort, and it only works for people who are home and paying attention.

The flexibility is real, though. EVs, home batteries, heat pumps and dishwashers can move hours of load without anyone being cold or late, if something trustworthy does it for them.

## What Ebb does

1. **Owners state preferences in plain English.** "Car at 80% by 7am, never below 19°C, dishwasher can wait." They can chat to their agent later: "Guests tonight, keep the heating on."
2. **The grid calls an event** for a zone (here, 30 homes on *Elm Street*): a turn-down (use less, 17:30–18:30) or a turn-up (use more, sunny Sunday).
3. **Household agents bid.** Each agent reads its home's preferences and live device state and offers kWh, a price per kWh, and the device actions it will take.
4. **Code validates and clears.** A validator trims or rejects anything that breaks a hard constraint (the car must still reach its charge by departure, the house must stay above its minimum temperature, the battery keeps its reserve). A merit-order auction then buys the cheapest bids until the target is met, at a uniform clearing price.
5. **Meters settle it.** Each home's metered use is compared with its baseline. Deliver at least 80% of what you promised and you're paid for what you delivered. Otherwise you're paid nothing, and told why.
6. **PayPal pays.** One Payouts batch per event goes from the aggregator's PayPal business account to each home's PayPal account, with live per-home status (pending, success, failed, unclaimed).

Positioning: Ebb is software for registered flexibility providers (aggregators and suppliers). It never holds funds. The aggregator pays its own customers from its own PayPal business account.

## Core principle: AI proposes, code pays

LLMs only ever produce **structured bids and explanations**, validated with zod. Every number that touches money (trimmed kWh, clearing price, delivered kWh, payout amount) is computed by deterministic, unit-tested code. Every decision, from agent reasoning to validator trims to PayPal status changes, is written to an audit log and shown in the UI.

## Architecture

```mermaid
flowchart LR
  subgraph Homes["30 homes · Elm Street"]
    P["Owner preferences<br/>+ chat"]
    S["Device state<br/>EV · battery · heat pump · appliances"]
    M["Smart-meter history<br/>(half-hourly)"]
  end

  subgraph AI["AI layer (proposes)"]
    HA["Household agents<br/>Claude Haiku 5.5<br/>structured bids"]
    PA["Preference agent<br/>chat → constraint changes"]
    AA["Aggregator agent<br/>Claude Sonnet 5.5<br/>explanations"]
  end

  subgraph Core["Deterministic core (decides & pays)"]
    V["Validator<br/>hard constraints"]
    C["Merit-order auction<br/>pay-as-clear"]
    B["Baseline<br/>10-day same half-hour"]
    ST["Settlement<br/>≥80% delivered → paid"]
  end

  subgraph PayPal["PayPal (sandbox)"]
    OA["OAuth 2.0<br/>client credentials"]
    PO["Payouts API<br/>1 batch / event<br/>idempotent sender_batch_id"]
  end

  CI["NESO Carbon Intensity API<br/>regional, by postcode"]
  GR["Live GB grid<br/>Elexon · Octopus Agile ·<br/>NESO DFS events"]
  DB[("SQLite · Drizzle<br/>events, bids, clearing,<br/>settlements, payouts,<br/>audit log")]
  UI["Control room<br/>Next.js"]

  P --> PA --> V
  P & S --> HA --> V --> C --> ST
  M --> B --> ST
  ST --> PO
  OA --> PO
  C & ST --> AA
  V & C & ST & PO & AA --> DB --> UI
  CI --> UI
  GR --> UI
  GR -- "mirror a real DFS event" --> C
```

| Layer | Where | What it does |
|---|---|---|
| Domain (pure, tested) | `src/domain/` | Homes, synthetic meter data, baseline, validator, clearing, delivery simulation, settlement, carbon maths |
| Agents | `src/agents/` | Household bid agent, aggregator explanations, preference chat, rule-based fallbacks |
| LLM providers | `src/llm/` | One interface; Anthropic (structured outputs), recording, and replay implementations |
| Orchestration | `src/core/` | Event pipeline, PayPal payouts with idempotency, audit log, scripted demo |
| PayPal client | `src/lib/paypal/` | OAuth, create batch, get batch, retries with backoff, duplicate resolution |
| App | `src/app/`, `src/components/`, `src/server/` | API routes, server-side demo runner, control-room UI |

## How PayPal is used

- **OAuth 2.0 client credentials** (`POST /v1/oauth2/token`), token cached until a minute before expiry, refreshed once on a 401.
- **Payouts API** (`POST /v1/payments/payouts`, `GET /v1/payments/payouts/{id}`): one batch per settled event, one item per home that earned money, amounts in GBP converted from integer pence only at the boundary.
- **Idempotency, in layers:** `sender_batch_id = ebb-<eventId>` is deterministic and also sent as `PayPal-Request-Id`. The database holds one batch row per event and never re-creates once it has PayPal's batch id. If the app crashes after PayPal accepted a batch but before saving its id, the retry reuses the same `sender_batch_id`. PayPal rejects the duplicate (`USER_BUSINESS_ERROR`, original batch linked in `details[].link`), and Ebb resolves and links the original batch instead of paying twice. This was verified against the live sandbox, and it's covered by tests that simulate both crash points.
- **Retries:** network errors, 429 and 5xx use exponential backoff with jitter. Failures are stored on the batch row, so the next attempt resumes.
- **Status:** the batch is polled until final; each home shows `pending` / `success` / `failed` / `unclaimed` from PayPal's `transaction_status`.
- The PayPal Agent Toolkit has no payouts tools (checked October 2026), so Ebb calls REST directly.

## How AI is used

- **Household agents** (`claude-haiku-5-5`, low effort: fast, cheap, lower-carbon) read the owner's own words, the hard limits, live device state and the baseline, and return a zod-validated bid via Anthropic structured outputs (`messages.parse` + `zodOutputFormat`). The prompt is deterministic and never contains the event id, so recorded responses replay exactly.
- **Aggregator agent** (`claude-sonnet-5-5`) explains the clearing result and settlement in plain English for the control room, using only the numbers it's given. It can't change them.
- **Preference agent** turns chat ("guests tonight, keep the heating on") into a permanent or expiring change to the home's constraints. Code sanitises every proposed value (ranges, valid times, devices the home actually has) before saving.
- **Models are configurable** via env. The provider interface means a local or fine-tuned model could be swapped in later.
- **Mock mode (`MOCK_LLM=true`, the default):** replays recorded agent responses from `fixtures/llm/` with no API key. Anything not recorded falls back to clearly labelled rule-based agents and a template explainer, so the whole app always runs.

## Live GB grid data

The control room pulls real, current data from three public APIs (no keys needed), cached server-side for 5–15 minutes and shown with its source and last-update time:

| Feed | Source | Shown as |
|---|---|---|
| Generation mix by fuel, last 24h | Elexon Insights (BMRS) `/generation/outturn/summary` | Zero-carbon share, mix bar, wind vs gas trend |
| System imbalance price and net imbalance volume | Elexon Insights `/balancing/settlement/system-prices/{date}` | £/MWh now, 24h chart, *system short/long* |
| Agile half-hourly retail price, South West (region L) | Octopus Energy API | Price now, published prices ahead, cheapest and priciest 2h windows |
| **Real Demand Flexibility Service events** | NESO Data Portal, *DFS Utilisation Report Summary* | The latest events NESO called: window, direction, MW asked vs bought, cost, implied p/kWh |

**Mirror a real NESO event.** Each DFS event has a *Mirror* button that creates the same event on Elm Street: the same window and direction (turn-down or turn-up, capped at four hours), a target scaled to the street (a quarter of its usual use for a turn-down, 60% extra for a turn-up), and a price cap anchored on what NESO actually paid (three times the implied average). It then runs through the normal bid → validate → clear → settle → pay pipeline. The audit log records which NESO event it mirrors.

![Live GB grid panel with real Elexon, Octopus Agile and NESO DFS data](docs/live-grid.png)

## Carbon

The control room shows live regional grid carbon intensity for the street's postcode (NESO Carbon Intensity API, South West England for `BS3`), the intensity during the event window, and an **indicative** CO₂ estimate. The estimate assumes shifted use would otherwise have happened at the 24-hour average intensity. It also shows the greenest two-hour window ahead, which is when heavy agent work (such as re-recording agent responses) should run. The demo events are dated beyond the API's 48-hour forecast, so the window uses the same UK time of day from the live forecast, labelled as such. If the API is unreachable, a typical profile is used and labelled.

## Quick start

Requires **Node 22+**. Windows, macOS and Linux.

```bash
git clone <this repo> && cd ebb
npm install
cp .env.example .env      # optional: PayPal sandbox credentials (see below)
npm run db:seed           # creates ./data/ebb.db with 30 synthetic homes
npm run dev               # http://localhost:3000, then press ▶ Run demo
```

Without PayPal credentials everything still runs; the payout step is shown as not configured. Without an Anthropic key the agents replay recordings or fall back to rules.

### PayPal sandbox setup (5 minutes)

1. Sign in at [developer.paypal.com](https://developer.paypal.com) → **Apps & Credentials** → **Sandbox** → create a REST app. Copy the **Client ID** and **Secret** into `PAYPAL_CLIENT_ID` / `PAYPAL_CLIENT_SECRET`.
2. **Testing tools → Sandbox accounts**: use (or create) 1–5 **Personal** accounts and put their emails, comma-separated, in `PAYPAL_SANDBOX_PAYEES`. The 30 homes are mapped onto them round-robin.
3. Check the connection, which sends one £1 sandbox payout and polls it to a final status:

```bash
npm run smoke:paypal
```

### Environment

| Variable | Default | Purpose |
|---|---|---|
| `DATABASE_URL` | `./data/ebb.db` | SQLite file (created and migrated automatically) |
| `PAYPAL_ENV` | `sandbox` | `sandbox` or `live` |
| `PAYPAL_CLIENT_ID` / `PAYPAL_CLIENT_SECRET` | — | Sandbox REST app credentials |
| `PAYPAL_SANDBOX_PAYEES` | — | Comma-separated sandbox personal-account emails |
| `PAYPAL_CURRENCY` | `GBP` | Payout currency |
| `MOCK_LLM` | `true` | Replay recorded agent responses; no key needed |
| `RECORD_LLM` | `false` | With `MOCK_LLM=false`, save live responses as fixtures |
| `ANTHROPIC_API_KEY` | — | Needed only for live agents or recording |
| `HOUSEHOLD_AGENT_MODEL` | `claude-haiku-5-5` | Household and preference agents |
| `AGGREGATOR_AGENT_MODEL` | `claude-sonnet-5-5` | Aggregator explanations |

### Commands

```bash
npm run dev                       # control room on :3000
npm test                          # 107 unit + integration tests (Vitest)
npm run typecheck && npm run lint
npm run event -- demo [--pay]     # the scripted demo from the terminal (--rules for rule-based agents)
npm run chat -- home-03 "Guests tonight, keep the heating on"
npm run llm:record                # record real agent responses for mock mode (needs ANTHROPIC_API_KEY)
npm run smoke:paypal              # one £1 sandbox payout, end to end
```

## The demo

Press **▶ Run demo**. It runs on the server, so everyone viewing the page (say, several judges on the hosted URL) watches the same run, and nobody can reset the street mid-demo. The narrator banner explains each step:

1. **Reset Elm Street.** 30 homes across eight household types, each with its own agent.
2. **An owner talks to their agent.** 3 Elm Street: "We've got guests tonight, so keep the heating on." The heat pump is now off-limits until 8am.
3. **The grid calls a turn-down**, Thursday 17:30–18:30: cut 40 kWh, paying up to £3/kWh.
4. **Household agents bid.** Watch the agent workflow and the live feed.
5. **Code validates and clears.** The validator trims over-promises (shortening an EV pause so the car still reaches its charge by departure, capping a heat-pump pause before the house drops below its minimum, keeping the battery reserve) and the merit-order chart fills to the target.
6. **Meters report, settlement runs.** 12 Elm Street's oven goes on at 17:40: it delivers 21% of its promise and gets £0, with the reason shown.
7. **PayPal pays the homes that delivered.** One sandbox Payouts batch, statuses update live.
8. **A sunny Sunday turn-up**, 12:00–14:00: soak up 100 kWh. EVs and batteries charge.
9. **Agents bid to use more.** 10. **Clear and settle.** 11. **PayPal pays again.**

Click any home to see its preferences, its agent's bid and reasoning, every validator change, its metered delivery chart, its PayPal status, and a chat box. The **Audit log** tab lists every decision with its reasoning.

## Deploy to Render

The repo includes a [`render.yaml`](render.yaml) Blueprint. In Render: **New → Blueprint → choose this repo**, then enter `PAYPAL_CLIENT_ID`, `PAYPAL_CLIENT_SECRET` and `PAYPAL_SANDBOX_PAYEES` when prompted (and optionally `ANTHROPIC_API_KEY`). The free plan's disk is ephemeral, which is fine: the database is migrated and the street re-seeded on boot. Health check: `/api/health`.

## Testing

107 tests cover the validator (EV departure, thermal model, battery reserve, appliance deadlines, excluded devices, schema failures), clearing (merit order, partial fill, pay-as-clear vs pay-as-bid, max price, tie-breaks), baseline, delivery simulation, settlement (threshold, caps, rounding), payout idempotency (double pay, re-settle, crash before and after PayPal accepts), the PayPal client (retries, token caching, duplicate resolution against the real sandbox response shape), LLM agents with a fake provider, record/replay, preference sanitising, carbon maths, and the grid-data parsers and NESO event mirroring (against trimmed copies of real API responses).

## Simulation and simplifications

- **Homes, devices and meter data are synthetic** and seeded, so every run is reproducible. Real deployments would read smart-meter data via the supplier/DCC and control devices through manufacturer APIs.
- **Baseline:** the mean of the same half-hour over the prior 10 days. Real schemes adjust for weekdays and weather.
- **Delivery** is simulated as baseline minus accepted kWh times a per-home performance factor, plus noise, with one scripted failure.
- **What households sell is flexibility, not electricity.** Selling electricity directly to neighbours needs a supply licence in Great Britain; flexibility is sold through an aggregator to NESO or a network operator, which is what Ebb models.
- **Money** is integer pence throughout; times are stored in UTC and shown in Europe/London; the market works in half-hour settlement periods.

## Built with

TypeScript (strict) · Next.js 16 (App Router) · SQLite + Drizzle ORM · zod · Anthropic SDK (Claude Haiku 5.5, Claude Sonnet 5.5, structured outputs) · PayPal REST APIs (OAuth 2.0, Payouts) · NESO Carbon Intensity API · Elexon Insights (BMRS) · Octopus Energy API · NESO Data Portal · Recharts · Tailwind CSS · lucide-react · Vitest · Render.

## Licence

[MIT](LICENSE)
