# Plainpay

**Medical bills explained by AI and paid through PayPal, with a person approving every step that moves money.**

A patient opens their statement. The assistant explains every line in plain English, checks the math, and flags anything worth questioning. Then the patient pays in full with one PayPal checkout, or asks the assistant for a payment plan, which becomes a schedule of real PayPal invoices. The clinic watches balances, payments and reviews arrive in one dashboard.

Built for the **PayPal AI Hackathon 2026** by Aryan Patel ([InsuraMed](https://insuramed.dev)).

| | |
|---|---|
| **Live demo** | `TODO: add the Render URL after deploying` |
| **Demo video** | `TODO: add the YouTube link` |
| **Devpost** | `TODO: add the Devpost project link` |

![Patient statement with the assistant's explanation and a flagged duplicate charge](docs/screenshots/patient-explain.png)

---

## Contents

- [Why it exists](#why-it-exists)
- [Features](#features)
- [How it works](#how-it-works)
- [Tech stack](#tech-stack)
- [Getting started](#getting-started)
- [Configuration](#configuration)
- [Running against the PayPal sandbox and Claude](#running-against-the-paypal-sandbox-and-claude)
- [Scripts](#scripts)
- [Project structure](#project-structure)
- [API reference](#api-reference)
- [Testing and verification](#testing-and-verification)
- [Deploying to Render](#deploying-to-render)
- [Security notes](#security-notes)
- [Screenshots](#screenshots)
- [Honesty notes](#honesty-notes)
- [License](#license)

## Why it exists

After insurance processes a claim, patients get a statement full of procedure codes, "allowed amounts" and "adjustments", and a number at the bottom they don't trust. Many don't pay, not because they can't, but because they don't understand why they owe it or whether it is even right. Clinic staff spend hours explaining bills over the phone.

Plainpay is the last step of the insurance workflow InsuraMed works on (authorization, then claim, then the patient understanding and paying their share): the explanation, automated and attached to a payment.

## Features

| | What happens | Powered by |
|---|---|---|
| **Explain** | A plain-English summary plus one explanation per line ("your plan allowed $980.00 and paid 80%; your 20% coinsurance is $196.00"). | Claude via the Anthropic Messages API, forced tool use for structured JSON |
| **Check** | Duplicate services on the same date, line items that don't add up to the printed total, and patient shares that don't follow the plan's math. Computed in code; the model only words them. | `src/services/billing.js` |
| **Ask** | Follow-up questions answered only from the statement. | Claude |
| **Request a review** | A flagged charge goes to the clinic for review; its amount is held out of the balance until billing removes or upholds it. | App |
| **Pay in full** | One PayPal checkout with the clinic's prompt-pay discount applied automatically, created and captured server side. | **PayPal Orders v2** and the **PayPal JS SDK** buttons |
| **Payment plan** | The assistant proposes a plan inside the clinic's policy (minimum monthly payment, maximum months, 0% interest). After the patient confirms, every installment becomes a PayPal invoice with a due date and a hosted pay page. | **PayPal Invoicing v2** (create, send, get) |
| **Clinic queue** | Every balance, plan, capture and open review in one grid, with an audit trail per account. | AG Grid Community |
| **Webhooks** | `PAYMENT.CAPTURE.COMPLETED` and `INVOICING.INVOICE.PAID`, signature-verified with PayPal. | PayPal Webhooks |
| **Offline mode** | `npm run dev` runs everything with no accounts: a PayPal stand-in that mirrors the API shapes Plainpay uses, and a deterministic rules engine instead of Claude. The UI labels both. | `src/services/paypal-simulator.js` |

## How it works

```
Browser (HTML + ES modules, no build step)
  index.html  patient page ──┐            clinic.html  dashboard (AG Grid)
                             ▼
Express API  (src/routes/*)  ── validates input, delegates ──►  services
                                                                 │
   billing.js   checks, verified balance, prompt-pay discount, plan options and schedules (pure functions)
   ai.js        Claude: explain / answer / propose_plan  ── falls back to the rules engine if Claude is unreachable
   payments.js  the only code that records money: orders, captures, reconcile, invoices, webhook updates
   reviews.js   holds and resolves disputed lines
   paypal.js    REST client: OAuth, Orders v2, Invoicing v2, webhook verification
                                                                 │
store.js  one JSON document (data/state.json), rebuilt from data/seed.json on reset
```

**The model explains; code decides.** The flags on a bill, the payable balance and the set of allowed payment plans are computed in `billing.js` and passed to Claude as context. Claude can word an explanation and choose one of the allowed plans, but it cannot add a flag, change what a patient owes, or pick a plan outside policy (an off-list choice is ignored). Nothing moves money without a click: the checkout, the payment-plan confirmation and every invoice send are triggered by the patient.

**Every payment is recorded exactly once.** The SDK callback, the redirect return (when the checkout popup is blocked), a reconcile that runs when the page opens, and webhooks can all report the same payment. `payments.js` matches on PayPal order and capture ids, refuses to capture a second order on a paid statement or an order created for a different statement, and guards against two concurrent captures.

## Tech stack

- **Runtime:** Node.js 20 or newer (developed and tested on Node 22), Express 4
- **Payments:** PayPal REST APIs (OAuth 2 client credentials, Orders v2, Invoicing v2, Webhooks) and the PayPal JavaScript SDK
- **AI:** Anthropic Messages API with tool use (`claude-sonnet-5-5` by default, falling back to `claude-haiku-4-5-20251001` if the configured model is unavailable)
- **Front end:** plain HTML, CSS and ES modules served as-is; AG Grid Community for the clinic grid; self-hosted fonts (Inter, IBM Plex Mono, Instrument Serif)
- **Storage:** a JSON file (prototype only)
- **Quality:** Node's built-in test runner, ESLint, Prettier, GitHub Actions
- **Hosting:** Render blueprint (`render.yaml`)

## Getting started

Prerequisites: [Node.js](https://nodejs.org) 20+ and npm. Nothing else is needed for offline mode.

```bash
git clone https://github.com/<your-account>/plainpay.git
cd plainpay
npm install
npm run dev
```

Open <http://localhost:3000> for the patient page and <http://localhost:3000/clinic.html> for the clinic dashboard. The header chips read **PayPal · simulator** and **AI · rules (mock)** in this mode.

There is no build step. `npm start` and `npm run dev` serve the source directly.

Try the demo patients in this order:

1. **Morgan Reed** (ER visit): *Explain my bill* flags the duplicate chest X-ray. *Request review of $12.40* holds it out of the balance. Pay the rest with PayPal; the receipt shows the capture id.
2. **Priya Nair** (physical therapy): the printed total ($460.00) doesn't match the lines ($420.00), so Plainpay uses the verified amount. *Talk to the assistant*, enter `70`, *Propose a plan*: six payments of $70.00, first due in 14 days. Confirm to create six invoices, pay one, then *Refresh payment status*.
3. **Clinic view:** the queue, the tiles, and an account drawer with its audit trail. Resolve Morgan's review there. *Reset demo* puts everything back.

## Configuration

Copy `.env.example` to `.env` (git-ignored) and fill in what you need. Variables already set in the environment take precedence over `.env`.

| Variable | Default | Purpose |
|---|---|---|
| `PAYPAL_MODE` | `sandbox` if `PAYPAL_CLIENT_ID` is set, else `simulate` | `sandbox`, `live` or `simulate` |
| `PAYPAL_CLIENT_ID` | | REST app client id (also sent to the browser for the JS SDK; it is public by design) |
| `PAYPAL_CLIENT_SECRET` | | REST app secret; never leaves the server |
| `PAYPAL_INVOICER_EMAIL` | | Optional. The business account email shown on invoices; it must belong to the account that owns the credentials |
| `PAYPAL_WEBHOOK_ID` | | Optional. Needed to verify webhook signatures; without it webhooks are rejected outside simulate mode |
| `AI_PROVIDER` | `anthropic` if `ANTHROPIC_API_KEY` is set, else `mock` | `anthropic` or `mock` |
| `ANTHROPIC_API_KEY` | | Anthropic API key (the account needs API credit) |
| `ANTHROPIC_MODEL` | `claude-sonnet-5-5` | Model for all three tools |
| `PORT` | `3000` | HTTP port |
| `PUBLIC_URL` | derived from the request | Public base URL used for PayPal return URLs |
| `DATA_FILE` | `./data/state.json` | Where demo state is saved |

`npm run dev` passes `--offline`, which forces `simulate` and `mock` regardless of `.env`. An unknown `PAYPAL_MODE` or `AI_PROVIDER` value stops the server at startup with a clear error.

## Running against the PayPal sandbox and Claude

1. **PayPal:** sign in at [developer.paypal.com](https://developer.paypal.com) → **Apps & Credentials** → **Sandbox** → open *Default Application* (or create an app) → copy the **Client ID** and **Secret**. Under **Testing Tools → Sandbox Accounts** note the **Business** account email (the invoicer) and the **Personal** account (the buyer).
2. **Anthropic:** [console.anthropic.com](https://console.anthropic.com) → **API keys** → create a key, and add credit under **Billing**.
3. Put them in `.env`:

   ```bash
   PAYPAL_MODE=sandbox
   PAYPAL_CLIENT_ID=...
   PAYPAL_CLIENT_SECRET=...
   PAYPAL_INVOICER_EMAIL=sb-...@business.example.com
   AI_PROVIDER=anthropic
   ANTHROPIC_API_KEY=...
   ```

4. `npm start` and open <http://localhost:3000>. The chips now read **PayPal · sandbox** and **AI · Claude**.

To pay in the sandbox checkout, log in with the sandbox Personal account, or choose **Pay with Debit or Credit Card** and use a test card from PayPal's [card generator](https://developer.paypal.com/api/rest/sandbox/card-testing/) (any future expiry and CVV). No real money moves in the sandbox.

The demo patients use fictional `example.com` emails, so PayPal's invoice emails bounce harmlessly. To receive one, change a patient's `email` in `data/seed.json` to a sandbox Personal account and reset the demo.

If Claude is unreachable (no credit, a rejected key, an outage), explanations and answers fall back to the rules engine and the page says so; *Re-explain* retries the model.

**Webhooks (optional):** in the developer dashboard add a webhook for `https://<your-host>/api/paypal/webhook` with the events `PAYMENT.CAPTURE.COMPLETED` and `INVOICING.INVOICE.PAID`, then set `PAYPAL_WEBHOOK_ID`. PayPal can't reach `localhost`, so this needs a deployed URL or a tunnel. Without webhooks, *Refresh payment status* pulls invoice status from PayPal.

## Scripts

| Command | What it does |
|---|---|
| `npm run dev` | Offline mode (PayPal simulator + rules engine), restarts on file changes |
| `npm start` | Runs with your `.env` / environment (sandbox, live or simulate) |
| `npm test` | All tests: unit, stubbed-Anthropic AI tests and end-to-end API flows against the simulator |
| `npm run lint` | ESLint |
| `npm run format` / `npm run format:check` | Prettier write / check |
| `npm run check` | Lint, format check and tests (what CI runs) |
| `npm run reset` | Deletes `data/state.json`; the next start rebuilds the demo from the seed |

## Project structure

```
plainpay/
├── server.js                    Entry point: starts the app on PORT
├── src/
│   ├── app.js                   Express app: middleware, static files, API, error handler
│   ├── config.js                Every environment variable, defaults and validation
│   ├── store.js                 JSON-file state, seed loading, demo date shifting
│   ├── routes/
│   │   ├── index.js             /api: boot config and the routers below
│   │   ├── statements.js        Patient API: read, explain, chat, review, checkout, payment plan
│   │   ├── clinic.js            Clinic API: account queue, review decisions, demo reset
│   │   └── webhooks.js          PayPal webhook receiver
│   ├── services/
│   │   ├── billing.js           Deterministic checks, balances, plan options and schedules
│   │   ├── ai.js                Claude client, prompts and tool schemas, rules-engine fallback
│   │   ├── payments.js          Orders, captures, reconcile, invoices, payment recording
│   │   ├── reviews.js           Review requests and clinic decisions
│   │   ├── paypal.js            PayPal REST client
│   │   └── paypal-simulator.js  Offline stand-in for the PayPal endpoints Plainpay uses
│   └── lib/
│       ├── money.js             Cent rounding and USD formatting
│       ├── dates.js             Calendar math in UTC
│       └── http.js              Async route wrapper, HttpError, rate limiter, error handler
├── public/
│   ├── index.html               Patient page
│   ├── clinic.html              Clinic dashboard
│   ├── js/                      patient.js, clinic.js, common.js (ES modules)
│   ├── css/                     styles.css (design tokens and components), clinic.css (grid theme)
│   ├── fonts/                   Self-hosted web fonts
│   └── favicon.svg
├── data/seed.json               Fictional clinic, policy and three statements
├── test/                        node:test suites
├── docs/screenshots/            Images used in this README
├── .env.example                 Configuration template with placeholders
├── render.yaml                  Render blueprint
└── .github/workflows/ci.yml     Lint, format check and tests on Node 22 and 24
```

## API reference

All endpoints take and return JSON. Errors are `{ "error": "message" }` with a meaningful status code.

| Method | Path | Purpose |
|---|---|---|
| GET | `/api/config` | Modes, PayPal client id, clinic name and policy |
| GET | `/api/statements` | All statements with computed balances |
| GET | `/api/statements/:id` | One statement |
| POST | `/api/statements/:id/explain` | Explain the bill (`{ "force": true }` to regenerate) |
| POST | `/api/statements/:id/chat` | `{ "message", "history" }` → answer from the statement |
| POST | `/api/statements/:id/dispute` | `{ "lineIds", "note" }` → hold lines for clinic review |
| POST | `/api/statements/:id/orders` | Create the PayPal order for the payable balance |
| POST | `/api/statements/:id/orders/:orderId/capture` | Capture an approved order (idempotent) |
| POST | `/api/statements/:id/orders/reconcile` | Finish a checkout that was approved but never captured |
| POST | `/api/statements/:id/plan/propose` | `{ "monthlyBudget" }` → plan proposal within policy |
| POST | `/api/statements/:id/plan/confirm` | `{ "months" }` → create and send one PayPal invoice per installment |
| POST | `/api/statements/:id/plan/refresh` | Sync installment status from PayPal |
| GET | `/api/clinic/accounts` | Dashboard rows and totals |
| POST | `/api/clinic/statements/:id/resolve-dispute` | `{ "outcome": "remove" \| "uphold" }` |
| POST | `/api/clinic/reset` | Restore the demo data |
| POST | `/api/paypal/webhook` | PayPal webhook receiver |

The assistant endpoints (`explain`, `chat`, `plan/propose`) are limited to 20 requests per minute per client.

## Testing and verification

```bash
npm run check   # ESLint + Prettier check + 37 tests, about 2 seconds, fully offline
```

- `test/billing.test.js`: checks, balances, discounts, plan options and schedules (cent-exact, month-end safe), date math.
- `test/ai.test.js`: Claude responses stubbed. The model's extra flags are discarded, off-policy plans are ignored, a missing model triggers one retry with the fallback model, and billing or auth errors fall back to the rules engine with a reason.
- `test/api.test.js`: boots the app against the PayPal simulator and runs every flow over HTTP: explain, chat, reviews, checkout (including idempotent capture, the reconcile safety net, cross-statement protection and a capture race), payment plans through completion, webhooks and reset.
- `test/rate-limit.test.js`: the assistant rate limit.

**Verified against the real PayPal sandbox (October 2026):** OAuth; order creation; PayPal's checkout page, approved with a sandbox test card through guest checkout; server-side capture, including the reconcile path that finishes an approved checkout when the page reopens; and a six-installment plan created and sent as real sandbox invoices with working pay links. Testing there exposed two problems the simulator could not show, both fixed: PayPal's 25-character limit on invoice numbers, and approved checkouts that never return to the page when the popup falls back to a full-page redirect.

**Not yet verified live:** Claude responses with a funded Anthropic account (the code path is covered by stubbed tests, and the fallback was observed live when the account had no credit), the JS SDK popup completing in a regular desktop browser (the embedded browser used for testing forced PayPal's full-page redirect), webhook delivery, live mode, and the Render deployment.

## Deploying to Render

1. Push the repository to GitHub.
2. In Render: **New → Blueprint**, select the repository. Render reads `render.yaml`.
3. Enter `PAYPAL_CLIENT_ID`, `PAYPAL_CLIENT_SECRET`, `PAYPAL_INVOICER_EMAIL` and `ANTHROPIC_API_KEY` when prompted (leave `PAYPAL_WEBHOOK_ID` empty unless you set up a webhook). Deploy.

The free plan's disk is ephemeral, so demo state lives in `/tmp` and resets when the service restarts or sleeps.

## Security notes

This is a hackathon prototype with fictional data. Before anything real:

- **There is no authentication.** Anyone with the URL can view the demo statements, use the clinic dashboard and reset the demo. Add accounts and authorization before storing real patient data.
- Secrets stay on the server and in `.env`, which is git-ignored. The PayPal client id is public by design.
- All text from statements, the model, chat and review notes is HTML-escaped before rendering, and only `https://` (or simulator) links become clickable.
- Request bodies are capped at 100 KB and free-text fields are length-limited. The assistant endpoints are rate limited.
- Webhooks are verified with PayPal's signature API outside simulate mode.
- The JSON file store suits a single demo instance only; use a database for anything more.

## Screenshots

Captured in offline mode; the same screens run against the PayPal sandbox.

**Payment plan:** the assistant's proposal inside clinic policy, and the six PayPal invoices with one paid.

![Payment-plan proposal and the resulting invoices](docs/screenshots/payment-plan.png)

**Clinic dashboard:** totals, the account queue and an account's invoices, payments and audit trail.

![Clinic dashboard with the account drawer open](docs/screenshots/clinic-dashboard.png)

**Receipt** after a PayPal capture:

![Payment receipt with the PayPal capture id](docs/screenshots/receipt.png)

## Honesty notes

- All patients, clinics, codes and amounts are fictional. "Evergrove Health Plan" is not a real insurer.
- The assistant explains statements. It does not give medical advice and cannot change what a patient owes.
- Flags come from deterministic checks; the model only explains them.
- No outcome metrics are claimed. This is a prototype running on PayPal's sandbox.

## License

[MIT](LICENSE) © 2026 Aryan Patel
