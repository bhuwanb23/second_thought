# Payday Agent — autonomous bounty payouts with PayPal

An agent that runs a micro-bounty board end to end. A requester posts a task with
a bounty; workers submit work; the agent **verifies each submission against the
acceptance criteria and instantly pays winners via the PayPal Payouts API** —
no human clicks between approval and money movement.

Built for the **PayPal AI Hackathon** (Best Use of Agentic Commerce).

## How it works

```
requester posts bounty ($25, acceptance criteria)
        |
worker submits work
        |
agent judges: PASS/FAIL per criterion -> approve / partial / reject
        |
approve/partial -> PayPal Payouts batch -> worker's PayPal email
        |
ledger: every verdict + payout batch ID, fully auditable
```

The verdict engine is deterministic (keyword rules against acceptance criteria),
so the demo needs no LLM key. An LLM adapter seam is left in `agent.ts`
(`judgeWithModel`) for a future upgrade.

## Run it

```bash
npm install
npm run build
npm start        # :3002
```

Open http://localhost:3002. A demo bounty is seeded on first run.

**Modes:** without credentials the app runs in mock mode (simulated PayPal
payouts with fake batch IDs). For live sandbox payouts:

```bash
PAYPAL_CLIENT_ID=... PAYPAL_SECRET=... npm start
```

Copy `.env.example` to `.env`. Sandbox only — never use production credentials.

## API

| Method | Route | Purpose |
|---|---|---|
| GET | `/api/health` | status + PayPal mode |
| GET | `/api/tasks` | list bounties |
| POST | `/api/tasks` | post a bounty `{title, description, criteria, bountyUsd, requesterEmail}` |
| POST | `/api/tasks/:id/submit` | submit work `{workerName, workerEmail, content, link?}` |
| POST | `/api/tasks/:id/verdict` | agent judges the latest submission and pays |

Criteria shape: `[{ text: "Mentions the brand", keywords: ["ember roast"] }]`.
Score >= 0.8 → full bounty; 0.5–0.8 → half; below → reject, no payout.

## Layout

```
src/
  paypal.ts   # PayPal sandbox client (mock/live): OAuth + Payouts API
  agent.ts    # bounty lifecycle + deterministic verdict engine
  index.ts    # HTTP server + API routes + static frontend
public/       # bounty board UI
```

## License

MIT. See [LICENSE](LICENSE).
