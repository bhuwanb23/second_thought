<p align="center">
  <img src="docs/cover.png" alt="Errand" width="800">
</p>

# Errand

**A shopping agent you chat or talk to. It searches 25,000 real stores, you choose, and it pays with PayPal on the spot.**

**Live demo:** https://errand-5pw6.onrender.com · Built for the [PayPal AI Hackathon](https://paypalaihackathon.devpost.com/) · [Devpost project](https://devpost.com/software/errand-7bsrzh) · MIT licensed

Errand is a conversational shopping agent with a real wallet. You brief it like a friend who shops well: "birthday gift for my dad who just got into trail running, budget $90". Jessica, the agent's voice, searches real retailers, shows you everything she found as large numbered cards, and when you say "buy number 4", pays for it with PayPal. No checkout screens after a one-time consent.

## Features

| | |
|---|---|
| **Chat or talk** | Type a brief or press Talk. Jessica replies in text and out loud, and narrates each search as it runs. Stop her any time. |
| **Real stores** | Every search covers 100M+ products from 25,000 retailers via Channel3, with per-retailer offers and store links. |
| **Numbered gallery** | Everything she finds appears as a large card with image, store, and price. Nothing is hidden behind a summary. |
| **Search by photo** | Attach a picture, add "something like this under $60", and get visual matches. "More like number 3" is a real similarity search. |
| **You stay in charge** | Buy, Add to cart, or Save for later on any card. Or say it: "add 2 and 5 to the cart", "save number 4", "check out my cart". The agent never buys unless told to. |
| **Pays with PayPal, instantly** | Connect PayPal once (PayPal Vault). After that "buy number 4" or "pay for my cart" completes the payment immediately and shows a receipt with the capture id. Not connected? You get a normal PayPal approval link. |
| **Cart, Saved, Orders** | Cart drawer that checks out as one PayPal order. Saved page. Orders page with status, items, totals, capture ids and store links; pending orders refresh from PayPal. |
| **Clean catalog** | Colour variants and relistings are de-duplicated. Prices are re-fetched seconds before checkout. Broken images fall back to alternates. |

## Architecture

![Errand architecture](docs/architecture.png)

The Next.js app sits in the middle. The agent (Claude, via the Claude Code CLI in print mode) gets its tools over MCP from an endpoint inside the same app, so API keys and the PayPal vault token never reach the model. Every chat message carries Gallery, Cart and Saved blocks that map card numbers to product ids, which is how "number 4" resolves exactly.

### Payment flow

![Payment flow](docs/payment-flow.png)

PayPal Vault turns a one-time approval into instant payments. The vault token lives server-side under an httpOnly session cookie, and the MCP endpoint looks it up from a session id in its URL, never from the prompt.

## Screenshots

| Chat + gallery (search by photo) | Landing page |
|---|---|
| ![](docs/screenshots/03-chat-gallery.png) | ![](docs/screenshots/01-landing.png) |

| Cart drawer | Orders |
|---|---|
| ![](docs/screenshots/04-cart.png) | ![](docs/screenshots/05-orders.png) |

## Stack

- **Next.js 16 / React 19 / TypeScript**, Server-Sent Events for the live agent stream
- **Claude** as the agent, run through the Claude Code CLI (`claude -p`, `--resume` per turn)
- **MCP** server inside the app at `/api/mcp` (`mcp-handler`), tools: `search_products`, `search_by_image`, `find_similar`, `get_product_offers`, `add_to_cart`, `save_for_later`, `create_paypal_checkout`
- **PayPal** Orders v2 (create, capture, multi-item) and Vault v3 (setup tokens, payment tokens, vaulted orders), sandbox
- **Channel3** product catalog: text, agentic, image and similarity search, per-retailer offers
- **ElevenLabs** Scribe (speech to text) and Flash (text to speech, voice "Jessica")
- **PayPal MCP server** (`@paypal/mcp`) wired into the dev environment via `scripts/paypal-mcp.sh`
- **Playwright** for browser QA of every flow

## Run it locally

Requirements: Node 22+, the [Claude Code CLI](https://claude.com/claude-code) installed and logged in (`claude` on your PATH), a PayPal sandbox app, a Channel3 API key, an ElevenLabs API key.

```bash
git clone https://github.com/ritwikareddykancharla/errand.git
cd errand
cp .env.example .env     # fill in the keys below
npm install
npm run dev              # http://localhost:3000
```

| Variable | Where to get it |
|---|---|
| `PAYPAL_CLIENT_ID`, `PAYPAL_CLIENT_SECRET` | [PayPal Developer Dashboard](https://developer.paypal.com/dashboard/), a sandbox app with Vault enabled |
| `PAYPAL_ENVIRONMENT` | `sandbox` |
| `CHANNEL3_API_KEY` | [trychannel3.com/developers](https://trychannel3.com/developers) |
| `ELEVENLABS_API_KEY` | [elevenlabs.io](https://elevenlabs.io) |
| `ELEVENLABS_VOICE_ID` | Optional, defaults to Jessica |
| `APP_URL` | Public base URL for PayPal return URLs. Defaults to `RENDER_EXTERNAL_URL` or `http://localhost:3000` |
| `CLAUDE_BIN`, `CLAUDE_MODEL` | Optional. Path to the `claude` binary, model override |

### Try it

1. Open `/app`. Type or say a brief, or attach a photo.
2. Press **Connect PayPal** in the header and approve once with a **sandbox buyer** account (Developer Dashboard, Sandbox accounts, the Personal one). From then on purchases pay instantly.
3. Say "buy number 2", or press Buy on a card, or add items to the cart and check out from the drawer.
4. See everything under **Orders**.

Without connecting PayPal, each purchase gives you an approval link instead; `/checkout/return` captures the payment after you approve.

## Pages

| Route | What |
|---|---|
| `/` | Landing page |
| `/app` | Chat with Jessica, numbered product gallery, cart, Buy buttons |
| `/saved` | Saved for later |
| `/orders` | Order history with status, items, store links, capture ids |
| `/search` | Manual search and buy, no agent |

## How the agent turn works

1. `POST /api/agent { message, sessionId?, gallery, cart, saved }` spawns `claude -p` with a system prompt, `--strict-mcp-config` pointing at `/api/mcp?buyer=…&visitor=…`, and `--allowedTools` limited to the shop tools. `--resume` continues the previous session.
2. The CLI's `stream-json` output is normalised into events (`session`, `text`, `tool_call`, `tool_result`, `done`) and streamed to the browser as SSE.
3. The browser turns tool events into gallery cards, activity lines, cart and saved updates, and speech.
4. `create_paypal_checkout` re-fetches prices from Channel3, creates one PayPal order (with `vault_id` when the buyer is connected), records it in `.data/orders.json`, and returns `paid: true` with a capture id or an approval URL.

## Safety rules

- The agent only buys on an explicit instruction. Its tool allowlist is enforced by the CLI, not by the prompt.
- Secrets live in `.env` and server-side files under `.data/`. The browser never sees API keys, and the model never sees the vault token.
- Disconnect PayPal from the header at any time; the vault token is deleted at PayPal.
- Sandbox only during the hackathon.

## Deploying to Render

`render.yaml` describes the service. Create it from the Dashboard (Blueprints, pick this repo) or via the Render MCP, then set the secret env vars: `PAYPAL_CLIENT_ID`, `PAYPAL_CLIENT_SECRET`, `CHANNEL3_API_KEY`, `ELEVENLABS_API_KEY`, and `ANTHROPIC_API_KEY` for the agent. The Claude Code CLI is bundled as a dependency, so `claude -p` works on the host with that key. `RENDER_EXTERNAL_URL` is picked up automatically for PayPal return URLs.

## License

MIT
