# Haggle

**Two AI agents haggle. PayPal holds the money.**

Haggle is a marketplace checkout where a buyer's agent and a seller's agent negotiate the price, PayPal
holds the agreed amount (authorize, not capture), and an AI inspector checks what arrived against the
listing and the seller's packing photos before any money moves. If the seller hid a defect, the agents
renegotiate from the evidence and PayPal captures less. If the buyer fakes damage, it goes to review
instead of an automatic discount.

Built for the [PayPal AI Hackathon](https://paypalaihackathon.devpost.com/) (2026). Sandbox only: no real money moves.

Demo video: _add YouTube link_

## How a deal works

| Step | What happens | PayPal |
|---|---|---|
| List | Seller sets a **public** asking price, a **private** minimum, and the most they'll knock off if it arrives not as described | |
| Negotiate | The buyer's agent reaches out first; the agents trade offers live. A deterministic referee enforces both private limits | |
| Hold | The buyer pays once. The money is held, not charged | Orders v2 `intent=AUTHORIZE` via the JS SDK button, then `authorize` |
| Ship | The seller must photograph the item while packing it | |
| Deliver | Haggle issues a one-time code (`HGL-1234`) the buyer handwrites in an arrival photo | |
| Inspect | Claude vision compares listing, packing, and arrival photos; plain code decides what happens next | |
| Settle | Full or partial capture; the remainder of the hold goes back to the buyer. Tracking attached, seller paid minus a 3% fee | Payments v2 `capture` (`final_capture: true`), `void`; Orders `track`; Payouts v1 |

After inspection, `inspect_item.route()` sends the deal one of four ways:

- **OK**: nothing undisclosed, so the seller is paid in full.
- **DEFECT**: an undisclosed defect that the seller's own packing photos show. The buyer can renegotiate (price only goes down, never below the seller's pre-set discount) or return it (hold released when the seller confirms receipt).
- **REVIEW**: damage that is *not* in the packing photos: shipping damage or an altered photo. A person decides; nobody is charged automatically.
- **RETAKE**: the delivery code isn't visible. Nothing about the item's condition is revealed, so a buyer can't probe the inspector. Three retakes, then review.

See [SPEC.md §10](SPEC.md) for the full fraud model.

## Design rule: models observe, code decides

The agents and the inspector are Claude (`claude-opus-5-5`, strict tool use). They never move money.

- **`negotiate.py` / `Referee`**: every offer passes through it. A buyer can't bid over its cap, a seller can't go
  under its floor or above the asking price, offers can't move backward, crossing offers settle at the earlier
  offer, and an agent's private limit is redacted from its messages before the other side sees them. Prices are
  `Decimal`, rounded to the cent before any check.
- **`inspect_item.route`**: turns the inspector's report into OK / DEFECT / REVIEW / RETAKE.
- **`server.py`**: one state machine; every transition is atomic and rejects out-of-order calls. The capture
  amount always comes from the server's own deal state, never from the browser. Every PayPal write carries a
  `PayPal-Request-Id` for idempotency.

## Run it

Requirements: Python 3.12+, a free [PayPal Developer](https://developer.paypal.com/) sandbox app (type
**Merchant**), and an [Anthropic API key](https://console.anthropic.com/). A full run costs a few cents of Claude usage.

```bash
git clone https://github.com/mihirargulkar/haggle.git && cd haggle
python3 -m venv .venv && .venv/bin/pip install -r requirements.txt
cp .env.example .env        # then fill in the three values
.venv/bin/python server.py  # http://localhost:8740
```

`.env`:

```
CLIENT_ID=your PayPal sandbox client ID
SECRET_KEY_1=your PayPal sandbox secret
ANTHROPIC_API_KEY=sk-ant-...
```

Open http://localhost:8740, keep the sample listing or write your own, and click **Start negotiation**. At the
payment step, log in to the PayPal popup with a **sandbox personal account** (Developer Dashboard → Testing
Tools → Sandbox Accounts).

**Skip the PayPal login:** `.venv/bin/python server.py --dev` adds a "Hold with a sandbox test card" button that
places the hold through the API with PayPal's published test card. Never run `--dev` on a public deployment.

The server is Python standard library only (`http.server`, server-sent events); the page is one HTML file
with no build step.

## Tests

```bash
.venv/bin/python -m pytest -q          # 42 tests, no network
.venv/bin/python sandbox_check.py      # live PayPal sandbox: hold, partial capture, void, reauthorize, payout
.venv/bin/python e2e.py seller_lied    # full deal against PayPal + Claude; also: fraud | nocode | ok
```

- `test_referee.py`: adversarial agents try to break every negotiation rule, plus a 2,000-run fuzz test that
  every deal lands inside both limits and offers never move backward.
- `test_route.py`: every inspection outcome, including the doctored-photo case.
- `e2e.py` draws its own synthetic product photos, so it needs no image files.

## Files

| File | |
|---|---|
| `negotiate.py` | Referee (deterministic negotiation rules) |
| `agents.py` | Two Claude negotiators bound to the referee by a strict `make_move` tool |
| `inspect_item.py` | Claude vision inspector + `route()` |
| `paypal.py` | Thin stdlib client for Orders, Payments, tracking, Payouts |
| `server.py` | Deal state machine + HTTP API + SSE streams |
| `index.html` | The whole UI |
| `video/` | Script and tooling that recorded the demo (Playwright + ffmpeg) |
| `SPEC.md` | Design spec, verified PayPal facts, fraud model |

## Limits (honest list)

- **Hold expiry**: PayPal holds last 29 days, with a 3-day honor period. `paypal.reauthorize` exists and is
  verified in `sandbox_check.py`, but no background job refreshes holds yet. Real shipping times need one.
- Delivery is a button, not a carrier webhook. Deals live in memory and are lost on restart.
- Haggle is the merchant of record and pays sellers via Payouts. A real marketplace would onboard sellers
  through PayPal's platform (multiparty) APIs instead.
- AI-edit detection is advisory only. The real defences are the packing photos, the delivery code, and the
  capped discount.
- On desktop browsers, `capture="environment"` doesn't force the camera.

## License

MIT. See [LICENSE](LICENSE).
