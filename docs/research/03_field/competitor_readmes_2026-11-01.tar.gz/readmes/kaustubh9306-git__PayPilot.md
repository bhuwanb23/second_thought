# PayPilot
PayPilot – AI agent built for PayPal AI Hackathon 2026. Automates invoicing, tracks payments, and sends smart reminders using PayPal APIs. Built with Python, FastAPI, MongoDB, React, and Docker for seamless orchestration.
