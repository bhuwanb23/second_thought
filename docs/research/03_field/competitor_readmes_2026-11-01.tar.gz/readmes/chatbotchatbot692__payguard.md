# PayGuard

A spending-policy guardrail that sits between an AI shopping agent and PayPal.

Autonomous agents that can pay are risky: a hallucinated amount, a prompt-injected merchant or a runaway loop spends real money. PayGuard makes every agent purchase pass a transparent policy before a PayPal order exists, and the buyer always approves on PayPal itself. The agent never moves money alone.

Built for the PayPal AI Hackathon on Devpost.

## How it works

1. A user (or agent) sends free text: "Buy a USB-C cable from Acme Store for $12".
2. The request is parsed into amount, currency, merchant and description. If `LLM_BASE_URL` and `LLM_API_KEY` point to any OpenAI-compatible endpoint, an LLM parses it; otherwise (or on any LLM error) a deterministic regex parser is used.
3. The policy engine returns `deny`, `needs_human` or `auto` with readable reasons. Checks: per-purchase cap, daily budget (pending orders count), currency allow-list, blocked keywords, optional merchant allow-list.
4. An AI reviewer gets the original text and the parsed purchase and rates the risk `low`, `medium` or `high` (cash equivalents under other names, prompt injection in the merchant or description, a parse that does not match the text, scam patterns). It can only tighten the verdict: `high` denies, `medium` turns `auto` into `needs_human`. It never runs on a request the policy already denied and can never approve anything. If the reviewer is unreachable, the request goes to a human.
5. Only allowed requests create a PayPal Orders v2 order (sandbox). Denied ones never reach PayPal.
6. The buyer approves on PayPal, then the dashboard captures the payment. Capture before approval is refused.
7. Every decision lands in an audit ledger shown in the dashboard.
8. The ledger is saved atomically to disk and the spending budget resets at the start of each UTC day.

## Run

Python 3.9+, standard library only.

```bash
python -m payguard.server
```

To turn on the AI parser and reviewer, point it at any OpenAI-compatible endpoint:

```bash
export LLM_BASE_URL=https://openrouter.ai/api/v1   # or any OpenAI-compatible API
export LLM_API_KEY=...                             # your key
export LLM_MODEL=...                               # a model id from that provider
```

Without these, parsing falls back to regex and the AI review is skipped (deterministic policy only).

The audit ledger is stored in `payguard-ledger.json`. Set `LEDGER_PATH` to keep it on a mounted volume in a deployment.

Open http://localhost:8000. Without PayPal credentials it runs in mock mode (offline PayPal stand-in with a "Simulate buyer approval" button). For the real PayPal sandbox set `PAYPAL_CLIENT_ID` and `PAYPAL_CLIENT_SECRET` from a sandbox app in the PayPal developer dashboard.

## Test

```bash
python -m unittest discover -s tests -t .
```

## Layout

- `payguard/policy.py` policy engine
- `payguard/llm.py` request parser (LLM or regex) and AI risk reviewer
- `payguard/paypal.py` PayPal Orders v2 client and offline mock
- `payguard/agent.py` orchestration and ledger
- `payguard/server.py`, `web/index.html` HTTP API and dashboard

## Limits

The default JSON ledger is appropriate for a single process, not concurrent replicas. Sandbox end-to-end was not run by the author for lack of sandbox credentials; the client is covered by tests with a fake transport. See `AI_DISCLOSURE.md`.

License: MIT.
