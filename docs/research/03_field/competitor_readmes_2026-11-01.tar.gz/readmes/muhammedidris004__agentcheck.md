# AgentCheck

Can an AI shopping agent actually pay on your store? AgentCheck runs checks (and optionally AI agents) through a
merchant's checkout, uses the PayPal sandbox to verify what really happened, and tells the merchant what to fix.

Built for the PayPal AI Hackathon (Oct 1 - Nov 12, 2026). MIT licensed.

> Status: work in progress. See [docs/PLAN.md](docs/PLAN.md).

## Try it (no keys, no PayPal account, no Chrome needed)

Hosted demo: _URL goes here once deployed (see [docs/DEPLOY.md](docs/DEPLOY.md))._

Or run it yourself, either way:

```bash
docker compose up              # http://localhost:4200
```

```bash
npm install
npm run build:web
npm run demo                   # http://127.0.0.1:4200
```

The demo replays real checker runs recorded earlier (the banner shows when, and with which AI model). It makes no live
checks and visits no site. To run the checks for real, use the live server below.

## Run it live

```bash
cp .env.example .env        # add PayPal SANDBOX credentials (and optionally GEMINI_API_KEY for the AI agent checks)
npm install
npm run build:web           # builds the dashboard
npm run server              # live API + fixture stores + dashboard at http://127.0.0.1:4200 (needs Chrome installed)
```

Development with hot reload: `npm run server` in one terminal, `npm run dev:web` in another (http://localhost:5173).
Without PayPal credentials the fixture stores create mock orders, so the demo still runs.

## Other commands

```bash
npm run stores:smoke              # proves each fixture store behaves as designed
npm run evaluate -- --agents none # runs the checker on every fixture store against the planted ground truth
npm run stress                    # six hold-out stores with different markup (cookie banner, 3-page funnel, late PayPal...)
npm run fixes:test                # applies the generated fixes and checks every store again
npm run check -- <store-url>      # check one store from the command line
npm run record                    # re-record the demo (add --agents dom,vision to include AI agent runs; limited by free quota)
npm run scan                      # fails if any secret from .env appears in a file; run before pushing
```

Only test stores you own or have permission to test. The server only allows the built-in fixture stores
(plus hosts listed in `ALLOWED_HOSTS`).
