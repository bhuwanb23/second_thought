# PayPilot ✈️ – Billing by chat

An AI billing agent for freelancers and small shops. Describe an invoice in plain language, approve it, and PayPilot creates and sends a **PayPal invoice**, tracks payment status, and drafts reminders for late payers. Built for the PayPal AI Hackathon.

![PayPilot](public/thumbnail.png)

## Run it (about 1 minute)

Requires Node.js 18+.

```bash
npm install
npm start
```

Open http://localhost:3000. With no keys it runs in **demo mode** (simulated PayPal and a rule-based parser), so you can try the full flow immediately.

## Go live (PayPal sandbox + Claude)

```bash
cp .env.example .env     # then fill in the keys
```

| Key | Where to get it |
|---|---|
| `PAYPAL_CLIENT_ID`, `PAYPAL_CLIENT_SECRET` | developer.paypal.com → Apps & Credentials → Sandbox app (the sandbox business account is the invoice sender) |
| `ANTHROPIC_API_KEY` | console.anthropic.com |

Restart with `npm start`. The badge at the top shows which mode is active. In live mode the client email is required, because PayPal sends the invoice by email.

## Try these messages
- `Invoice Ravi 12000 for logo design, due Friday`
- `Who owes me money?`
- `Remind Ravi` (also `Remind Ravi, firm` or `final`)

## How it works
- **Claude** converts chat into a structured action (`create_invoice`, `query`, `remind`) and writes reminder text. Without a key, a rule-based parser takes over.
- **PayPal Invoicing API v2** (sandbox) creates and sends the invoice.
- **Webhook** `POST /api/webhook` marks an invoice paid on `INVOICING.INVOICE.PAID`. Register it on your sandbox app after deploying (for example on Render). The **Simulate payment** button does the same locally.
- **Safety:** the agent can only call fixed actions, and every invoice or reminder needs human approval.

## Deploy on Render
New Web Service → connect this repo → Build `npm install` → Start `npm start` → add the env vars.

## Known limits
Webhook signature verification is not implemented yet, invoices are stored in a local JSON file, and PayPal sandbox support for INR invoices may be limited (use USD if PayPal rejects it).

## License
MIT
