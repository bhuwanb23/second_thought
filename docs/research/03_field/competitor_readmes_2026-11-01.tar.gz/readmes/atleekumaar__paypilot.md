# PayPilot

> PayPilot is an AI-powered commerce agent that helps users discover, evaluate, and purchase products through PayPal.

Built for the **[PayPal AI Hackathon](https://paypalaihackathon.devpost.com/)**.

---

## Vision

PayPilot empowers everyday consumers to shop using natural conversational language. Instead of browsing dozens of tabs, comparing spec sheets manually, and dealing with tedious multi-step checkouts, a user simply states their intent:

> *"Find me a laptop under $1200 for AI development with good battery life."*

PayPilot autonomously understands the request, searches product offerings, compares benchmarks and user reviews, synthesizes the best recommendations, formulates a precise purchase plan, requests explicit user confirmation, and seamlessly completes the payment with PayPal.

---

## Current Status & Roadmap

- **Phase 1 — Foundation** ✅
  - FastAPI backend & Next.js frontend scaffolded
  - Health and root status endpoints
  - Git repository & clean architecture established

- **Phase 2 — AI Product Discovery** ✅
  - Natural-language intent extraction and normalization
  - Deterministic product search enforcing hard constraints (budget, category, in-stock)
  - Mathematical ranking engine (0–100 composite scoring)
  - Grounded, hallucination-free recommendation explanations
  - Interactive Next.js Shopping Workspace with progressive loading & product modals

- **Phase 3 — PayPal Checkout & Purchase Flow** ✅
  - Authoritative Purchase Plan formulation (zero client price manipulation)
  - Explicit Human-in-the-Loop approval gate
  - PayPal Sandbox OAuth 2.0 authentication and token management
  - PayPal Orders API v2 order creation and authoritative amount binding
  - PayPal Sandbox checkout flow with `● PayPal Sandbox` visual indicator
  - Server-side order capture verification and idempotency protection
  - Verified receipt and payment success screen

- **Phase 4 — Controlled Agentic Commerce** ✅
  - Multi-step tool-augmented AI agent (`UNDERSTAND -> PLAN -> USE TOOLS -> SEARCH -> COMPARE -> RECOMMEND -> CREATE PURCHASE PLAN -> REQUEST APPROVAL -> EXECUTE APPROVED PAYMENT`)
  - Tool Registry with 4 strict permission tiers (`READ`, `WRITE`, `APPROVAL_REQUIRED`, `PAYMENT`)
  - Policy Engine enforcing 6 deterministic safety rules ($0 autonomy threshold, no price tampering, out-of-stock guard, step limit)
  - Conversational Agent UI with real-time operational Activity Log and inline Purchase Approval Cards
  - Multi-turn conversational memory with pronoun/reference resolution ("buy the first one", "why NovaBook?")
  - 100% verified test suite (41/41 passing tests)

- **Phase 5 — Post-Purchase Agent** ✅ *(ACTIVE & IMPLEMENTED)*
  - Authoritative Order & Shipment tracking models with strict user isolation (`order.user_id == current_user.id`)
  - Post-Purchase Agent with multi-turn order inquiry intents (`ORDER_STATUS`, `TRACK_ORDER`, `DELIVERY_ESTIMATE`, `PAYMENT_STATUS`, `DELIVERY_DELAY`)
  - Deterministic delivery delay detection and carrier telemetry parsing
  - Consequential action safety gate: drafting support inquiries (`WRITE`) vs. dispatching to merchant (`APPROVAL_REQUIRED`)
  - Complete frontend Order Tracking Dashboard (`/orders`), Order Detail with milestone timeline (`/orders/[id]`), and Notification Center (`/notifications`)
  - 100% verified test suite (56/56 passing tests)

- **Phase 6 — Production Polish** ⏳
  - Security hardening, telemetry, and hackathon presentation demo

---

## Phase 5 Post-Purchase End-to-End Walkthrough

```text
1. Post-Purchase Inquiry:
   User: "Where is my NovaBook?"
       ↓
2. Agent Dispatches Tools:
   - Tool `get_order(order_id="ORD-001")`: Retrieves authoritative order & shipment state
   - Tool `get_shipment_status`: Retrieves carrier tracking milestones
       ↓
3. Grounded Response:
   "Your NovaBook Pro 14 order is currently in transit.
    Payment: ✓ Completed
    Order: ORD-001
    Shipment: In Transit
    Estimated delivery: October 18, 2026
    Last update: Package arrived at the regional facility. Regional logistics delay reported."
       ↓
4. Delay Inquiry:
   User: "Why hasn't it arrived yet?"
       ↓
5. Issue Detection Engine:
   - Evaluates estimated delivery (Oct 18) vs. current date and carrier delay notation
   - Detects `DELIVERY_DELAY` (Severity: MEDIUM)
       ↓
6. Action Recommendation:
   "The shipment appears to be delayed. The original estimated delivery date was October 18, 2026,
    but the shipment is still in transit.
    Carrier note: Regional logistics delay reported.
    Recommended next step: Check latest carrier update or contact merchant.
    Would you like me to prepare a support request?"
       ↓
7. Draft Preparation:
   User: "Prepare a support request."
   - Agent executes `prepare_support_request` (Non-consequential WRITE tool)
   - Generates structured draft: Subject, Recipient, Message
   - Halts and prompts: "Send this request? [Cancel] [Approve & Send]"
       ↓
8. Explicit Human Approval & Dispatch:
   User clicks [Approve & Send]
   - Policy Engine verifies explicit user approval
   - Executes `send_support_request` (APPROVAL_REQUIRED tool)
   - Dispatches inquiry and confirms with Ticket Reference: TICK-XXXXXX
```
1. Natural Language Intent:
   User: "Find me a laptop under $1200 for AI development with good battery life."
       ↓
2. Agent Planner:
   Formulates structured workflow: [search_products -> compare_products]
       ↓
3. Policy Engine Verification:
   Evaluates tool permissions (search_products: READ, compare_products: READ) -> ALLOW
       ↓
4. Tool Execution & Catalog Grounding:
   - Discovers candidate models (NovaBook Pro 14, AeroBlade Slim, VisionBook 15)
   - Evaluates specs, scores, and trade-offs
       ↓
5. Grounded Conversational Response & Activity Stream:
   Presents top pick with pros/cons while logging real-time operational audit entries.
       ↓
6. Purchase Intent:
   User: "I like the NovaBook Pro 14, let's buy it."
       ↓
7. Controlled Purchasing Guard:
   - Agent executes `create_purchase_plan` (Price: $1,049 derived strictly from backend)
   - Agent attempts `request_purchase_approval` -> Policy Engine halts execution!
   - State transitions to `AWAITING_APPROVAL`.
       ↓
8. Human-in-the-Loop Decision:
   - Frontend renders interactive Purchase Approval Card.
   - User reviews exact SKU, quantity, seller, and authoritative total.
   - User clicks [Approve Purchase].
       ↓
9. Approved Payment Execution:
   - Agent resumes execution.
   - Policy Engine verifies explicit user approval.
   - Authoritative PayPal Sandbox order is generated.
   - User seamlessly completes transaction via PayPal Sandbox Smart Buttons.
```
1. Search: "Find me a laptop under $1200 for AI development with good battery life."
      ↓
2. AI Recommendations: PayPilot recommends NovaBook Pro 14 (#1 Pick, $1,049.00).
      ↓
3. Product Selection: User clicks "Select" on the top choice.
      ↓
4. Purchase Plan Formulated:
   - Item: NovaBook Pro 14
   - Authoritative Price: $1,049.00 USD (Derived by backend from verified catalog)
   - Seller: Nova Direct
   - Delivery: 3 days
   - Why: Best balance of GPU performance and battery endurance.
      ↓
5. Explicit User Approval: User reviews the summary and clicks [Approve Purchase].
      ↓
6. PayPal Sandbox Order Created:
   - Backend calls PayPal Orders API v2.
   - Generates authoritative PayPal Order ID.
      ↓
7. PayPal Checkout:
   - User approves in PayPal Sandbox.
      ↓
8. Server-Side Capture:
   - Backend captures the order directly with PayPal API.
   - Verifies capture status is COMPLETED.
      ↓
9. Verified Receipt Screen:
   - Shows green checkmark, Amount Paid ($1,049.00 USD), PayPal Order ID, and Capture ID.
```

---

## PayPal Sandbox Setup Instructions

PayPilot is configured for **PayPal Sandbox Mode** to ensure no real money is processed during testing.

### 1. Obtain PayPal Sandbox Credentials
1. Log in to the [PayPal Developer Dashboard](https://developer.paypal.com/dashboard/).
2. Navigate to **Apps & Credentials** and select the **Sandbox** tab.
3. Create a new REST API app or use the Default Application.
4. Copy your **Client ID** and **Secret**.

### 2. Configure Local Environment
Create or edit your local `.env` file in the repository root:
```env
PAYPAL_CLIENT_ID=your_sandbox_client_id_here
PAYPAL_CLIENT_SECRET=your_sandbox_client_secret_here
PAYPAL_ENVIRONMENT=sandbox
```
*(Note: If no credentials are configured, PayPilot seamlessly activates its local Sandbox emulation mode so judges and automated tests can run without blockers).*

### 3. Sandbox Buyer Accounts
To complete sandbox transactions, use the Sandbox personal buyer account provided in your PayPal Developer dashboard under **Sandbox → Accounts** (e.g. `sb-buyer...@personal.example.com`).

---

## Architecture Flow

```text
                 USER
                   │
                   ▼
              NEXT.JS UI
                   │
                   ▼
          DISCOVERY API (POST /api/discovery/search)
                   │
                   ▼
           PRODUCT SELECTED
                   │
                   ▼
          PURCHASE PLAN (POST /api/purchase-plans)
                   │
                   ▼
        EXPLICIT USER APPROVAL (POST /api/purchase-plans/{id}/approve)
                   │
                   ▼
         PAYPAL ORDER SERVICE (POST /api/payments/paypal/create-order)
                   │
                   ▼
            PAYPAL SANDBOX
                   │
                   ▼
             CAPTURE (POST /api/payments/paypal/capture)
                   │
                   ▼
         PAYMENT VERIFICATION (status == "COMPLETED")
                   │
                   ▼
          SUCCESS CONFIRMATION RECEIPT
```

---

## API Endpoints

### Agentic Commerce API
- `POST /api/agent/chat` — Conversational interaction with the autonomous commerce agent (pre- & post-purchase).
- `POST /api/agent/{session_id}/approve` — Explicit human approval resuming agent for PayPal orders or support ticket dispatch.
- `POST /api/agent/{session_id}/deny` — Graceful user cancellation of the active plan or draft.
- `GET /api/agent/{session_id}/state` — Full session state snapshot (current step, status, plan, order).
- `GET /api/agent/{session_id}/actions` — Real-time operational audit log and activity trace.
- `GET /api/agent/{session_id}/summary` — Compact execution telemetry (turn count, goal, tool usage).

### Orders & Tracking API
- `GET /api/orders` — List user's verified orders with shipment status and user isolation.
- `GET /api/orders/{order_id}` — Complete order detail with carrier milestones and verification status.
- `GET /api/orders/{order_id}/tracking` — Real-time tracking telemetry and carrier scans.
- `GET /api/orders/{order_id}/issues` — Deterministic issue detector evaluating delivery delays.

### Notifications API
- `GET /api/notifications` — List in-app proactive alerts (delays, shipping, payment).
- `POST /api/notifications/{id}/read` — Mark a notification as read.

### Purchase Plans API
- `POST /api/purchase-plans` — Create purchase plan with backend-derived authoritative price.
- `GET /api/purchase-plans/{id}` — Retrieve purchase plan details.
- `POST /api/purchase-plans/{id}/approve` — Explicitly approve a purchase plan.

### Payments & PayPal API
- `POST /api/payments/paypal/create-order` — Create PayPal Sandbox checkout order for an approved plan.
- `POST /api/payments/paypal/capture` — Capture PayPal payment, verify completion, and issue receipt.
- `GET /api/payments/{id}` — Retrieve payment transaction record.
- `GET /api/payments/by-plan/{plan_id}` — Retrieve payment record by purchase plan ID.

### Discovery & Products API
- `POST /api/discovery/search` — Natural language product search and explainable recommendation.
- `GET /api/products` — Retrieve product catalogue with filters.
- `GET /api/products/{id}` — Single product details by SKU.

### System API
- `GET /health` — Health check endpoint.
- `GET /docs` — Interactive OpenAPI / Swagger UI.

---

## Local Development

### 1. Backend Setup
```bash
cd backend
python -m venv .venv
# Activate:
.venv\Scripts\Activate.ps1   # Windows PowerShell
source .venv/bin/activate      # macOS/Linux

pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

### 2. Frontend Setup
```bash
cd frontend
npm install
npm run dev
```
Open [http://localhost:3000](http://localhost:3000) in your browser.

### 3. Run Automated Tests
```bash
cd backend
pytest
```

---

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.
