# Haggle

Tell Haggle what you want and your maximum price. Your AI agent negotiates with the merchant's AI agent, and **PayPal charges you only after you approve the final deal**.

Built for the PayPal AI Hackathon (Best Use of Agentic Commerce).

## Quick start (judges: no keys needed)

```bash
git clone <this repo> && cd haggle
npm start            # needs Node 22.9+, zero dependencies
# open http://localhost:3000
npm test             # engine guardrail tests
```

With no keys, Haggle runs scripted agents and a simulated PayPal order so it works offline. For the real thing:

```bash
cp .env.example .env   # then fill in the keys
```

| Variable | Effect |
| --- | --- |
| `ANTHROPIC_API_KEY` | Agents become Claude models instead of scripted turns |
| `PAYPAL_CLIENT_ID` / `PAYPAL_CLIENT_SECRET` | Real PayPal **sandbox** Orders flow (create, approve, capture) |

Sandbox keys: create an app at <https://developer.paypal.com/dashboard/applications/sandbox> and pay with a sandbox personal account. Never use real money.

## Deploy on Render

Create a new **Blueprint** on Render pointing at this repo (it reads `render.yaml`), then add the three optional keys in the dashboard. `RENDER_EXTERNAL_URL` is picked up automatically for the PayPal return link.

## How it works

1. Buyer picks a product and a private maximum price.
2. `src/engine.js` runs up to 6 rounds. The buyer agent offers, the merchant agent counters.
3. **Guardrails live in code, not in prompts:** the merchant never sells below its floor, the buyer never pays above the maximum, the round limit always ends the negotiation, and a merchant message that leaks the floor is redacted.
4. The buyer sees the final deal and taps **Approve**. Only then does the server create a PayPal order, using the stored deal price (never a client-sent amount), and capture it on return.

## Models

| Role | Model | Why |
| --- | --- | --- |
| Buyer agent | `claude-haiku-5-5` | Fast and cheap; many short turns |
| Merchant agent | `claude-sonnet-5-5` | Better at holding margin and persuading |

Override with `BUYER_MODEL` / `MERCHANT_MODEL`. If a model call fails or returns bad JSON, that turn falls back to the scripted agent, so a demo never stalls.

## Layout

```
src/engine.js    negotiation loop + guardrails
src/agents.js    scripted and Claude agents (same interface)
src/paypal.js    PayPal Orders v2, sandbox
src/server.js    HTTP + server-sent events
public/          buyer chat and merchant dashboard
test/            guardrail tests
```

## Known limits

Deals are kept in memory, the merchant dashboard has no login, and negotiation is price-only (no bundles or shipping yet).

## License

MIT
