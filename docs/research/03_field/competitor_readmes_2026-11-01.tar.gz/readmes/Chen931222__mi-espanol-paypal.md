# Mi Español Plus

Five minutes of Latin American Spanish a day, for adults in Taiwan. This build adds an AI conversation partner, a Plus subscription paid with PayPal, and shop scenes where you actually pay, in Spanish.

**Live demo:** https://mi-espanol-paypal.vercel.app (PayPal sandbox; no real money moves)

Built for the PayPal AI Hackathon 2026. Mi Español was already live before October 2026; everything below the line "What changed for the hackathon" was built after October 1, 2026.

## The problem

Self-taught learners in Taiwan can find lessons, flashcards and grammar notes. What they cannot find is someone to talk to who will wait while they type a sentence, answer at their level, and tell them in Chinese why a sentence was wrong. A private tutor costs far more per hour than most learners will pay every day.

Mi Español already gives them a daily five-minute ritual: one dialogue from 14 everyday scenes, five fill-in-the-blank items, and the cards they got stuck on. All of its checking is rule-based. It can say exactly whether an answer matches, but it cannot hold a conversation.

## What changed for the hackathon

1. **AI partner (Claude Haiku 5.5).** A fourth mode in the dialogue tab. Pick any of the 14 scenes and talk freely; the model plays the other person in simple Mexican Spanish, translates each reply into Traditional Chinese, and when you make a real mistake it shows the corrected sentence and a one-line reason under your message. Every correction goes into the site's existing mistake book, where you later rebuild the sentence tile by tile.
2. **Mi Español Plus (PayPal Subscriptions).** Free learners get 3 AI conversations a day, 20 turns each. Plus is NT$60 a month and removes the daily conversation limit (200 turns a day). The subscription is verified server-side against PayPal before a device counts as Plus, re-checked every few hours, and can be cancelled from the progress tab.
3. **Pay in Spanish (PayPal Orders, agentic).** In the clothes shop, the café and the market, the AI shopkeeper takes your order in Spanish. When you are ready, it calls a `create_bill` tool; the server builds a PayPal order from a fixed price list (the model never sets prices), the page shows a printed ticket with a PayPal button, and after you pay with a sandbox buyer account the shopkeeper thanks you and the ticket gets a PAGADO stamp. Paying abroad is one of the first real things a learner has to do in Spanish; here they rehearse it end to end.

## How it works

```
browser (index.html)                         Vercel functions (Node)                    services
-------------------                          -----------------------                    --------
AI partner mode  ── POST /api/tutor ───────▶ quota check (Upstash Redis)
                                             Claude Haiku 5.5, JSON reply schema ─────▶ Anthropic API
                                             tool create_bill → price list → order ───▶ PayPal Orders v2 (sandbox)
ticket + PayPal button (JS SDK, capture) ──▶ POST /api/checkout → capture order ──────▶ PayPal Orders v2
Plus card + PayPal button (JS SDK, sub) ───▶ POST /api/plus → verify subscription ────▶ PayPal Subscriptions v1
                                             GET /api/plus, /api/config
```

- The page is one static file; all lesson data lives in it. `tools/extract-scenes.mjs` copies the 14 scenes into `api/_lib/scenes.js`, so the tutor can only role-play scenes that exist on the site.
- Each browser gets a random device id in localStorage. There are no accounts; Plus is attached to the device that subscribed (up to 3 devices per subscription).
- A global daily ceiling on AI turns keeps the API bill bounded.

## Try it (judges)

1. Open https://mi-espanol-paypal.vercel.app and choose **對話練習 Conversación** in the side menu (on a phone: the 對話 tab).
2. Pick the scene **買衣服 · En la tienda de ropa**, then the mode **AI 夥伴 · IA**, and press **開始聊 · Empezar**.
3. Type in Spanish, for example `Hola, quiero un camiseta azul.` (the mistake is on purpose; watch the correction appear).
4. Say you want to pay, for example `Eso es todo, ¿cuánto es?`. A ticket with a PayPal button appears. Log in with the sandbox buyer account below, or use the debit/credit card button with a PayPal sandbox test card and set the card form's country to United States.
5. Open **學習進度 Progreso**: the top card is Mi Español Plus. Subscribe with the same sandbox buyer account, then go back to the AI partner and see the daily limit lifted.

Sandbox buyer account (a US personal account): provided in the Devpost testing instructions. The card form was tested with the country set to United States; other countries were not tested.

## Run it yourself

Requirements: Node 20+, a Vercel account, an Anthropic API key, a PayPal developer sandbox app, and an Upstash Redis store connected to the Vercel project.

```bash
npm install
cp .env.example .env.local   # then fill in the values
node tools/paypal-setup.mjs  # creates the sandbox product and monthly plan, appends PAYPAL_PLAN_ID
vercel dev
```

To look at the screens without any keys, `node tools/dev-mock.mjs` serves the site with fake API responses on http://localhost:5190.

## Honest limits

- The AI's Spanish and its corrections are model output and can be wrong. The page says so next to every correction. The rest of the site stays rule-based.
- The lesson Spanish has not been reviewed by a native speaker yet.
- Shop prices are invented for practice. Payments run in the PayPal sandbox only.
- PayPal does not let a Taiwan-registered buyer pay a Taiwan-registered merchant. We hit this in the sandbox, so the demo merchant is a US sandbox account.
- The interface is in Traditional Chinese with Spanish practice material, because the learners are in Taiwan.

## Licenses

- Code: MIT, see [LICENSE](LICENSE).
- Lesson text, dialogues and Chinese explanations: © 2026 Chen931222, all rights reserved, see [NOTICE](NOTICE).
- Example sentences from [Tatoeba](https://tatoeba.org): CC BY 2.0 FR; sentence-by-sentence sources are listed in [SOURCES.md](SOURCES.md).
- Some line icons are taken from or based on [Feather](https://feathericons.com), MIT; its license notice is in [NOTICE](NOTICE).
