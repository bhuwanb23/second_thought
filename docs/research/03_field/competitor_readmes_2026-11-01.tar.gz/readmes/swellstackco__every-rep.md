# Every Rep

**Live demo: https://everyrep.swellstackco.com** (PayPal sandbox, no real money)

Every Rep is pay-per-rep fundraising that settles on the spot. Friends pledge a dollar amount per push-up (or squat, or jumping jack) and pick a limit. PayPal holds that limit as an authorization. A webcam counts the reps in the browser. When the clock hits zero, each donor is charged exactly `min(reps x rate, cap)`, the rest of their hold is released, and the cause is paid out with PayPal Payouts. Nobody types results into a spreadsheet a week later, and nobody is charged more than they agreed to. The authorization is the donor's cap.

Built for the PayPal AI Hackathon. Everything runs in PayPal sandbox or in a built-in mock. No real money moves.

Demo video (under 3 minutes): https://youtu.be/kXA6OFi34RQ

## Try it (judges)

1. Open https://everyrep.swellstackco.com and press **Try it now**. It makes a pretend challenge for "Lincoln Elementary PTA" with five labeled demo donors (never charged) and opens the live screen. Allow the camera, do a few push-ups from a side view (or press "No camera? Tap to count"). Watch the reps, the dollars, and the donor tiles. At TIME the demo donors show "Demo. No charge."
2. To test the real PayPal money path, use the QR code on the live screen (or open the donor link `/d/<challenge id>`) as a donor. Pick a rate and a limit, press **Pledge with PayPal**, and sign in with the sandbox buyer account: see Devpost testing instructions. Approve. That creates a real sandbox authorization. Then count reps on the live screen. At TIME the server captures `min(reps x rate, cap)` from your authorization and voids the rest. Open the organizer page to see the ledger and press **Pay** to send the Payouts batch.
3. Sandbox only. Demo challenges delete themselves after 24 hours, and demo creation is rate limited (10 per hour per IP).

## Run it locally (mock mode, no keys)

Needs Node 22 or newer.

```
npm install && cp .env.example .env && npm run dev
```

Open http://localhost:5193 (API on :5141). A fake PayPal approval page stands in for PayPal, so no account or keys are needed. Production build: `npm run build && npm start` (serves everything on :5141).

Pages: `/` landing, `/organize/:id?k=KEY` organizer (QR, donors, ledger, payout), `/d/:id` donor phone page, `/live/:id?k=KEY` the TV screen.

## What is real and what is simulated

Real:
- PayPal sandbox Orders v2 with `intent=AUTHORIZE`, the authorization, the final capture, the void, and Payouts. These run against PayPal's sandbox API with a sandbox app.
- Push-up, squat and jumping-jack counting with MediaPipe Pose, in the browser, from the webcam.
- Claude Haiku writes the thank-you lines and the recap, and looks at three small camera frames per run as a spot-check.

Simulated:
- The five demo donors on the "Try it now" screen are labeled bots. They never touch PayPal, are not charged, and are left out of the ledger and payout.
- Mock mode (`ER_MODE=mock`) replaces PayPal with a local stand-in that keeps the same interface in SQLite. The video was recorded in mock mode, and its stand-in athlete is a stock clip fed to the real counter as a fake webcam.
- All people, schools and causes in the demo are made up. All money is sandbox money.

## PayPal calls

| Step | Endpoint | When and why |
| --- | --- | --- |
| Pledge | `POST /v2/checkout/orders`, `intent=AUTHORIZE` | The donor approves a hold for their cap (for example $25). The donor is redirected to PayPal and back. |
| Hold | `POST /v2/checkout/orders/{id}/authorize` | On return, the server authorizes the approved order. The authorization is the donor's limit. Nothing is charged yet. |
| TIME, reps > 0 | `POST /v2/payments/authorizations/{id}/capture`, `final_capture=true` | The server captures `min(reps x rate, cap)`. Final capture releases the rest of the hold. |
| TIME, 0 reps | `POST /v2/payments/authorizations/{id}/void` | The hold is released and the donor pays nothing. |
| After everyone settles | `POST /v1/payments/payouts` (status: `GET /v1/payments/payouts/{id}`) | One payout batch sends the total charged to the cause's PayPal email. The batch id is the idempotency key, so a retry cannot pay twice. |

Rules the server enforces: a donor is never charged above their cap; the count is bounded by the clock (the camera cannot report more reps than a human can do in the window); captures and payouts are idempotent; demo donors never touch PayPal. After TIME, three AI spot-checks of camera frames (25%, 50%, 95% of the window) can hold the charges for the organizer to confirm the count.

Auth is `POST /v1/oauth2/token`. Authorization status is read with `GET /v2/payments/authorizations/{id}`.

Code: `src/server/paypal/` (`live.ts` is the real client, `mock.ts` is the same interface kept in SQLite), `src/server/challenge/` (pledge, run, settle, ledger, payout).

## How counting works

MediaPipe Pose (`@mediapipe/tasks-vision` pinned to 1.2.0) runs in the live screen. The wasm and the pose model are served from `src/web/public/mediapipe/`, not from a CDN. Per-exercise rep counters in `src/shared/pose/` use joint angles with hysteresis and a minimum rep time. Push-ups need a side view; squats and jumping jacks work front-on. "No camera? Tap to count" is the fallback. Video never leaves the device, except the three small spot-check frames.

## Modes

- Mock (default): `ER_MODE=mock`. A fake PayPal approval page stands in for PayPal. Needs no keys.
- Sandbox: `ER_MODE=live` with `PAYPAL_CLIENT_ID` and `PAYPAL_CLIENT_SECRET` from a PayPal sandbox app in `.env`. `npm run probe:paypal hold | void | payout <email>` checks the money path against the sandbox (it refuses to run against live PayPal).
- AI: `LLM_PROVIDER=anthropic` with `ANTHROPIC_API_KEY` writes thank-you lines, the recap, and the spot-checks. Default `mock`. Spend is capped (`LLM_SPEND_CAP_USD`, default $4).

## AI tools used

- Claude Haiku 5.5 (Anthropic API): donor thank-you lines, the end-of-run recap, and the three-frame spot-check that can hold charges for the organizer to confirm. Output is length-limited and checked; there is a fallback line if the model fails, and a hard spend cap (`LLM_SPEND_CAP_USD`, default $4).
- MediaPipe Pose (`@mediapipe/tasks-vision` 1.2.0, `pose_landmarker_lite`): rep counting, in the browser. Served from this repo, not a CDN.
- Kokoro TTS (local, free): the voice-over in the demo video and the pre-recorded live-screen clips. No browser speech synthesis.
- Claude Code (Claude Opus and Sonnet): wrote most of the code, tests and the video pipeline, with a human directing and reviewing.

## Prior art

Per-unit pledge platforms already exist: 99Pledges, RallyUp, PledgeStar, EAAA Missions, The Push-Up Challenge (AU). They count on paper or by self-report and charge later, either saved cards after an organizer enters the results (99Pledges says there is no cap) or an emailed pay link. Camera rep counters exist too (Pushup Club, Pushup Battle on Devpost) but they involve no money. We did not find anything that counts live and settles live. Every Rep's difference in one line: nothing counts live AND settles live, and here the PayPal authorization is the donor's cap.

## Safety and limits

- A demo. It moves no real money, and the people in it are fictional.
- A donor is never charged above their cap. The authorization makes that true at the PayPal level, and the server checks it again.
- The rep count is bounded by the clock, so the camera cannot report more reps than a human can do in the window. Captures and payouts are idempotent, so a retry cannot charge or pay twice.
- Video stays on the device. Only three small spot-check frames per run go to the model, and only when AI is on.
- Not validated on a wide range of bodies, cameras or lighting. Push-ups need a side view. Rep counters were tuned on a small set of clips, so treat the thresholds as a starting point. "Tap to count" is the fallback, and the organizer can confirm or correct the count before anyone is charged.
- No secrets live in this repo. PayPal keys and the Anthropic key go in a local `.env` that is git-ignored.

## Credits

The demo video's stand-in athlete is Pexels video 4804817 ("Topless Man Doing Push-Ups"), used under the Pexels License: https://www.pexels.com/video/topless-man-doing-push-ups-4804817/ . It is a stand-in for the camera test, not a real athlete or endorsement. Fonts: Barlow and Barlow Condensed.

## Voice

The live screen plays pre-recorded clips only. There is no browser speech synthesis. A line with no clip shows as text. `scripts/voice-lines.txt` holds the lines, and `LINES_APPROVED=1 npm run voice:gen` writes `data/voice/*.mp3` and `manifest.json`.

## Tests

```
npm run typecheck
npm test                 # vitest
npm run build && npm run e2e   # Playwright, muted (--mute-audio plus ?test=1)
npm run readability      # reading grade and style lint for player-facing text
```

## License

MIT. See `LICENSE`.
