# Haggle Court

Entry for the PayPal AI hackathon. Two heckling bots haggle a group buy, a judge bot reads the receipt and the group chat, rules who owes what, and PayPal sandbox payment requests go out. Sandbox only, no real money.

Concept and demo story: [docs/concept-haggle-court.md](docs/concept-haggle-court.md). Dated public-source notes on agent payments: [docs/market-notes.md](docs/market-notes.md).

## Status

Work in progress. A demo runs on Render in PayPal sandbox mode: https://haggle-court.onrender.com (free tier, sleeps when idle). The sandbox demo uses a test-card payment source, so buyer-wallet login and approval are not required for that path. Sandbox authorization, capture, void and payouts were verified in development, including group-purchase success and failure rollback. The separate PayPal-wallet checkout path is wired into the demo UI (the Approve-as-buyer button) but still needs a Personal sandbox buyer to approve an order; that approval run is not verified yet. No keys are in this repo.

## Layout

- `src/haggle/` - Haggle Court: negotiation, judge, PayPal sandbox calls, server, web page
- `src/pool/` - group-funding coordinator
- `payments/` - pointer to `src/pool/`
- `tests/` - tests for haggle and pool
- `docs/` - concept and notes

## Try the live AI role yourself
The public demo runs scripted lines (the hosted Google key was removed Oct 25, 2026 ahead of trial-credit expiry). To see the Gemini role, run locally with a free Google AI Studio API key, which needs no billing account: create one at https://aistudio.google.com/apikey (about a minute), then:

    export GEMINI_API_KEY=your-key
    PYTHONPATH=src python3 -m haggle.server

Then open http://localhost:8000 and check `/healthz`: `"ai": "gemini"` means live via the API key, `"vertex"` means live via a Google Cloud service-account key (`GOOGLE_APPLICATION_CREDENTIALS` or `GOOGLE_SA_JSON`, Vertex AI enabled), `"scripted"` means fallback. `ANTHROPIC_API_KEY` works as another alternative provider.

## Buyer-wallet approval path
`Approve as buyer` on the page (or `POST /api/wallet/start`) negotiates a price and creates an AUTHORIZE order that the buyer must approve in PayPal. PayPal redirects to `/wallet/return`, which authorizes the approved order once (tokens are single-use and server-issued), then the court rules, captures or voids, and requests payouts. In mock mode the approval link is the return link. Against the real sandbox it needs a Personal sandbox buyer account and `PAYPAL_CLIENT_ID` / `PAYPAL_CLIENT_SECRET`; that real-sandbox run is not verified yet. Request shape and the full flow are tested against a local fake PayPal server in `tests/test_wallet.py`.

## Run and test

```sh
PYTHONPATH=src python3 -m unittest discover -s tests -v
PYTHONPATH=src python3 -m haggle.server
```

Open http://localhost:8000 and /pool. GET /healthz returns health and payment mode.
The public free Render instance can take time to wake; a single failed fetch is not proof the service is down.

## Demo limits

- Banter is scripted by default. If a Google Cloud key is configured (`GOOGLE_SA_JSON` or `GOOGLE_APPLICATION_CREDENTIALS`), Gemini on Vertex AI writes the bot banter and suggests the judge's weights. Code computes every price and share (model text has digits stripped, weights are clamped). Any error or call cap (`HAGGLE_MAX_LLM_CALLS`, `HAGGLE_MAX_LLM_CALLS_PER_DAY`) falls back to scripted lines. `/healthz` and each run report which mode was used. The pool coordinator is deterministic rules.
- The canned group demo simulates human approval and merchant purchase. It is not a production human-authentication flow.
- Mock PayPal and simulated Venmo are never labeled real sandbox funding.
- A payout batch ID confirms submission, not delivery. Failed payouts stay distribution_pending; failed refunds/voids stay compensation_pending.
- Webhooks are bounded and deduplicated. Sandbox mode rejects unsigned events or a missing webhook ID. Mock receipts are unverified and never drive settlement. Live webhook delivery verified against the real sandbox Oct 23, 2026 (signed capture accepted, simulated unverifiable post refused).
- The current event log is in memory, not a durable idempotency or recovery ledger. Do not use this demo with real funds.
