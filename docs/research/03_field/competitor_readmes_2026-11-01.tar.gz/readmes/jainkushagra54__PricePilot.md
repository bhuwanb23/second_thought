# PricePilot

A price watcher that knows how much it's allowed to spend.

You tell it what you want, the most you'll pay and your rules in normal words ("new only, under $600 with shipping, no cases"). It checks the shops you trust. When a listing passes every rule, it creates a PayPal checkout and sends you the link on Telegram. Nothing gets charged until you approve it on PayPal.

Built for the PayPal AI Hackathon 2026.

## How it works

1. **You add an item**: the product, a hard budget, your rules and the shops to watch.
2. **Gemini reads the rules** and turns them into structured JSON. It can only make the budget lower, never higher.
3. **Prices get checked**, either on a timer or with the "Check prices now" button. Demo shops come from the database; real shops come from the Channel3 API.
4. **Gemini checks each listing** is the exact product, not a case or a different model. The answer is saved, so the same listing isn't asked about twice.
5. **Plain JavaScript decides** (`backend/src/services/policy.service.js`). It checks budget, condition, stock, seller, keywords and the AI match score. The AI never makes this decision.
6. **PayPal Orders API v2**: for a passing demo-shop listing, the backend creates an order with an idempotency key and gets the approval link.
7. **You approve**: you open the link and pay with a sandbox account. The backend captures the payment, and a PayPal webhook confirms it.
8. **Activity log**: every step is saved for each item, so you can see why something was or wasn't bought.

## Tech used

| Part | What |
| --- | --- |
| Frontend | React 18, Vite, React Router, Recharts, plain CSS |
| Backend | Node.js, Express, Zod for validation, JWT login |
| Database | PostgreSQL on Neon (free), through Prisma |
| AI | Google Gemini API (Flash model, JSON output) |
| Payments | PayPal Orders API v2 and Webhooks, Sandbox |
| Product data | Channel3 search API (optional) |
| Alerts | Telegram Bot API (optional) |
| Hosting | Render |

Everything is plain JavaScript. The backend uses CommonJS (`require`) and the frontend uses JSX.

## Running it locally

You need Node.js 20 or newer.

```bash
npm run install:all
npm run db:setup
npm run dev
```

Fill in the `.env` file in the project root first. Both the backend and the frontend read that one file. The API runs on http://localhost:4000 and the site on http://localhost:5173.

## Trying the demo

1. Sign up. You get two demo shops with some sample phones.
2. Watch "Aurora X1 smartphone 128GB" with a limit of 600 USD and the rules "new only, total with shipping, no cases or renewed ones".
3. Press **Check prices now**. The cheapest new one is $644 with shipping, so it gets blocked on budget.
4. Go to **Stores**, change the Orbit Mart 128GB price to 579 and save.
5. Check again. A PayPal Sandbox order is created. Press **Pay with PayPal** and log in with your sandbox personal account.
6. PayPal sends you back to PricePilot, which captures the payment and marks the item as bought.

## API

| Method | Path | What it does |
| --- | --- | --- |
| POST | /api/auth/register, /api/auth/login | Sign up, log in |
| GET, PATCH | /api/auth/me | Profile and Telegram chat ID |
| CRUD | /api/stores, /api/stores/:storeId/products | Shops and demo listings |
| CRUD | /api/missions | Watched items |
| POST | /api/missions/:id/parse-rules, /check, /pause, /resume | Item actions |
| GET | /api/missions/:id/snapshots, /audit | Price history and activity |
| GET | /api/orders | PayPal orders |
| POST | /api/orders/paypal/:paypalOrderId/capture, /cancel | Finish or cancel a checkout |
| POST | /api/webhooks/paypal | PayPal webhook, signature checked |
| POST | /api/internal/check-prices | Timed check, needs the x-cron-secret header |
| GET | /api/health | Health check |

## License

MIT
