# Theervu (தீர்வு)

**Ungal Urimai. Engal Theervu.**
*Your Rights. Our Resolution.*

Every consumer deserves a clearer path to resolution.

Theervu is a consumer problem-resolution platform, designed first for Indian consumers dealing with unresolved online shopping problems. It helps people organise case information, keep evidence notes, track events, prepare clear communications and see possible next steps, instead of juggling scattered screenshots, chat threads, complaint numbers and dates.

> **Phase 1 prototype.** This repository contains the frontend foundation only. It uses fictional demonstration data and in-memory state. There is **no real AI processing, no authentication, no persistent storage, no file uploads and no external integrations**. Theervu provides organisational and communication assistance. It does not guarantee any outcome and does not replace professional legal advice.

---

## The problem

When an online order goes wrong (a refund that never arrives, a parcel marked delivered that never came, a rejected replacement, a product that fails within warranty), the information needed to resolve it ends up scattered across apps, emails, screenshots and memory. Consumers often do not know what to try next or when to follow up.

**Core journey:** Describe the problem → Organise the case → Understand next steps → Prepare communications → Track progress.

Initial categories: delayed refunds, missing or undelivered orders, return and replacement disputes, warranty and defective-product issues, and "Other".

## Phase 1 scope

Implemented:

- Brand identity: wordmark, Tamil name, official slogan, icon system (Lucide), design tokens.
- Public landing page.
- Interactive dashboard with summary-card filters, search, status and category filters, sorting, recent activity and an "AI action centre" **preview** that uses local rules, not AI.
- Create-a-case form with validation.
- Case detail screen with timeline, evidence notes (metadata only), follow-ups, rule-based next steps, a template message outline and resolution progress.
- Privacy and trust page.
- Responsive layouts for desktop, tablet and mobile browsers.
- Unit tests for the data and logic layer.

Out of scope for Phase 1 (planned for later phases, only with explicit approval): real accounts and authentication, a database or cloud persistence, any live AI provider (Gemini, Groq, OpenRouter or others), AI-generated analysis or messages, file uploads, OCR, email, WhatsApp, SMS or push notifications, scheduled follow-ups, retailer integrations, payments, automated complaint submission, legal filing, analytics, and native Android or iOS apps.

## Screens and routes

| Route | Screen | Notes |
| --- | --- | --- |
| `/` | Landing page | Hero with slogan, product preview (demo data), how it works, supported issues, trust and privacy, final call to action. |
| `/dashboard` | Dashboard | Summary cards, search, filters, sorting, case list, AI action centre preview, recent activity. |
| `/cases/new` | Create a case | Accepts `?category=<issue_category>` to preselect a category, for example `/cases/new?category=delayed_refund`. |
| `/cases/[id]` | Case details | For example `/cases/THV-1001`. An unknown ID shows a "Case not found" state with links back. |
| `/privacy` | Privacy and trust | Prototype status, data handling, sensitive-information guidance, future AI considerations, disclaimer. |
| any other path | 404 page | Branded "Page not found" with links to the dashboard and home page. |

## Technology stack

- [Next.js](https://nextjs.org) 16.4 (App Router, Turbopack, Cache Components and Partial Prefetching enabled by the scaffold)
- React 19.3
- TypeScript 5.9 (`strict` mode)
- Tailwind CSS 4.3
- Lucide React for icons
- Vitest 5 for unit tests
- ESLint 9 with `eslint-config-next`
- npm

Fonts (Plus Jakarta Sans and Noto Sans Tamil) are loaded with `next/font/google`, which downloads them **at build time** and serves them from the app itself. Visitors' browsers do not contact Google Fonts.

## Project structure

```text
src/
├── app/                       # Routes (App Router)
│   ├── layout.tsx             # Root layout: fonts, metadata, header, footer, case store provider
│   ├── page.tsx               # Landing page
│   ├── dashboard/page.tsx
│   ├── cases/new/page.tsx
│   ├── cases/[id]/page.tsx
│   ├── privacy/page.tsx
│   ├── not-found.tsx
│   ├── icon.svg               # Favicon (Theervu mark)
│   └── globals.css            # Design tokens and base styles
├── components/
│   ├── brand/                 # Logo mark and wordmark
│   ├── layout/                # Site header (with mobile menu) and footer
│   ├── ui/                    # Buttons, form fields, panels, alerts, empty states, notices
│   ├── landing/               # Landing page sections
│   ├── dashboard/             # Summary cards, filters, case cards, activity, action centre
│   └── cases/                 # Case form, detail view, timeline, evidence, follow-ups, progress
└── lib/
    ├── types.ts               # Domain models (Case, TimelineEvent, EvidenceItem, FollowUp, ...)
    ├── case-config.ts         # Status, category and option definitions (single source of truth)
    ├── case-logic.ts          # Pure functions: search, filter, sort, counts, progress, guidance
    ├── case-actions.ts        # Pure reducer for all case mutations
    ├── case-store.tsx         # React context holding in-memory prototype state
    ├── validation.ts          # Form validation
    ├── format.ts              # Deterministic date formatting (IST)
    ├── routes.ts              # Route helpers
    ├── brand.ts               # Official brand copy
    ├── data/demo-cases.ts     # Fictional demonstration data
    └── *.test.ts              # Unit tests
```

## Prerequisites

- Node.js 22.12 or later, or 24.x (Next.js 16 needs 20.9 or later, and Vitest 5 needs 22.12 or later). Developed and verified with Node.js 24.19.
- npm 10 or later (verified with npm 12.2)

## Getting started

```bash
npm install
```

```bash
npm run dev
```

Then open <http://localhost:3000>.

## Available scripts

| Command | What it does |
| --- | --- |
| `npm run dev` | Start the development server. |
| `npm run build` | Create a production build. |
| `npm run start` | Serve the production build (run `npm run build` first). |
| `npm run lint` | Run ESLint. |
| `npm run typecheck` | Generate Next.js route types, then run `tsc --noEmit`. |
| `npm test` | Run the Vitest unit tests once. |
| `npm run test:watch` | Run Vitest in watch mode. |

## Prototype data behaviour

- Seven **fictional** demonstration cases (`THV-1001` to `THV-1007`) load on every page load. Merchant names, order references, amounts and events are invented. Merchant "responses" in the seed data are labelled as recorded by the fictional consumer.
- Cases and updates you add (new cases, status changes, evidence notes, follow-ups, recorded responses, "message prepared" records) are held **in memory in the current browser tab only**. They are not written to `localStorage`, cookies or any server.
- **Reloading or closing the page resets everything to the demonstration data.** A case created in the session (for example `THV-1008`) shows "Case not found" after a reload.
- Navigating between pages inside the app keeps your changes.
- Summary-card counts, filters, progress and recent activity are all derived from the same records, so they stay consistent as data changes.
- "Follow-ups due" counts unresolved cases that have at least one planned follow-up not yet marked done. It does not depend on today's date.

## How guidance works (no AI)

- **Possible next steps**: fixed, category-specific general guidance, adjusted for status.
- **Missing information**: a short rule-based checklist (order reference, purchase date, evidence, merchant contact recorded, follow-up planned).
- **Message outline**: a fixed template filled with the case's own fields. Labelled "Not AI-generated". Theervu never sends it.
- **AI action centre**: a clearly labelled *preview*. Each suggestion is either a link into the case or the local checklist above.

## Known limitations

- No persistence: data resets on reload (by design for Phase 1).
- No authentication or user accounts. The dashboard is a single shared demo view.
- Evidence is metadata only. No files can be attached.
- Follow-ups are reminders shown in the app only. Nothing is sent and no notifications fire.
- Guidance is generic and rule-based, not tailored legal or professional advice.
- Copy to clipboard depends on the browser's Clipboard API. Where it is blocked, the outline text is selected so it can be copied with Ctrl+C or ⌘+C.
- `npm audit` reports 5 high-severity advisories in the development-only lint toolchain (`eslint-config-next` → `fast-glob` → `micromatch` → `braces`). The only automatic fix downgrades `eslint-config-next` to a Next.js 14 version, so it was not applied. These packages are not part of the production bundle.
- The Next.js CLI collects anonymous telemetry by default (this is developer tooling, not the app). You can disable it with `npx next telemetry disable`.

## Notes for contributors

- This project uses Next.js 16 with **Cache Components**. Recently visited routes stay mounted (hidden) via React `<Activity>`. Form IDs therefore use `useId()`, case section anchors include the case ID, and the create-case form resets itself after a successful submission when hidden. See `node_modules/next/dist/docs/` (referenced from `AGENTS.md`).
- Dates are formatted manually in Indian Standard Time so server and browser output always match.
- `.claude/launch.json` is a local preview configuration for Claude Code. It is not needed to run the app.

## Future phases (not started)

Possible later work, subject to review and explicit approval: authentication, secure persistent storage, carefully scoped AI assistance (with clear consent and data handling), real evidence uploads, notifications and reminders, Progressive Web App support, and integrations.

---

© 2026 Theervu. Phase 1 prototype.
