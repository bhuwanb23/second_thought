# PayPilot AI — Autonomous Financial Assistant

> **"Your Money. Your Goals. Your AI Agent."**  
> *Developed for the PayPal AI Hackathon 2026*

---

## 🌟 Overview

**PayPilot AI** is a production-grade, full-stack autonomous financial assistant that marries **mathematically deterministic financial engineering** with **Google Gemini 3.8's contextual reasoning** and **PayPal Sandbox Checkout**.

In consumer fintech, LLMs must never hallucinate bank account balances, shortfalls, or transaction amounts. PayPilot AI solves this through a hybrid architecture:

```
USER FINANCIAL DATA
        ↓
FINANCIAL CALCULATION ENGINE (Deterministic Node.js Service)
        ↓
GEMINI AI REASONING & EXPLANATION (Google Gen AI SDK with gemini-3.8-flash)
        ↓
PURCHASE RECOMMENDATION (Fits Budget / Affordable with Caution / Delay)
        ↓
EXPLICIT USER APPROVAL (Zero Autonomous/Unchecked Charging)
        ↓
PAYPAL SANDBOX CHECKOUT (Server-Side Verified Capture)
```

---

## 🚀 Key Features

1. **Autonomous Financial Assistant (Gemini 3.8):**
   - Professional conversational interface grounded directly in the user's active financial snapshot.
   - Answers inquiries such as *"Can I afford a laptop for ₹45,000?"*, *"Where can I reduce expenses?"*, *"How much did I spend on food this month?"*, and *"Which laptop is suitable for AI/Data Science students?"*.
   - Never fabricates numbers; asks clarifying follow-up questions when parameters are missing; clearly tags Demonstration Data vs. Verified User Data.

2. **Purchase Intelligence Engine:**
   - Server-side deterministic affordability analysis based on:
     - Net discretionary cash flow = `Monthly Income - Monthly Expenses - Monthly Savings Target`
     - Liquid buffer = `Current Savings - Protected Emergency Floor`
   - Three authoritative verdicts:
     - 🟢 **Fits the Stated Budget:** Affordable completely out of monthly cash surplus without touching savings.
     - 🟡 **Affordable with Caution:** Affordable by utilizing extra liquid savings while keeping the emergency reserve 100% intact.
     - 🔴 **Consider Delaying the Purchase:** Item exceeds safe limit or breaches the sacred emergency reserve.
   - Computes exact numerical shortfalls, reserve retention, and savings goal delay in months.
   - Gemini translates arithmetic into plain-language actionable advice.

3. **AI Smart Shopping Agent:**
   - Verified product catalogue (AI Workstations, student laptops, ANC headphones, 4K developer monitors).
   - Real specifications, advantages, trade-offs, and suitability scores.
   - One-click transfer to **Purchase Intelligence** or direct **PayPal Sandbox Checkout**.

4. **Interactive Financial Dashboard & Analytics:**
   - 6 key metrics: Income, Expenses, Available Budget, Total Savings, Monthly Target, Goal Progress.
   - Recharts visualisations: Cash-flow allocation bar chart, categorical expense distribution donut chart, 50/30/20 gold-standard budget compliance.
   - Burn-rate velocity tracking and automated optimization suggestions.

5. **Smart Savings Planner:**
   - Goal progress tracking with target deadlines and required monthly contributions.
   - Gemini AI savings acceleration strategies for each goal.

6. **Financial Ledger & Transactions (CRUD):**
   - Full Create, Read, Update, and Delete capabilities.
   - Clear visual badges distinguishing Sample Demonstration Data from User-Verified Data.
   - Instant "Reset Demo Data" and CSV Export.

7. **Official PayPal Sandbox Checkout & Payment History:**
   - Strict server-side catalogue price verification (`POST /api/paypal/create-order`).
   - Browser never dictates prices or currency without server confirmation.
   - Server capture (`POST /api/paypal/capture-order`) with confirmed transaction receipts.
   - **Dedicated Payment History Section:** Displays past PayPal transactions with confirmed capture status (`COMPLETED` / `PENDING`), execution date & time, USD and local equivalent amounts, item description, and printable receipt review.
   - Diagnostic status indicator for PayPal Sandbox credentials (`PAYPAL_CLIENT_ID` & `PAYPAL_CLIENT_SECRET`).

---

## 🛠️ Technology Stack

- **Frontend:** React 19, TypeScript, Tailwind CSS, Recharts, Lucide React, Framer Motion.
- **Backend:** Node.js, Express, TypeScript (TSX).
- **AI Model:** Google Gemini (`gemini-3.8-flash`) via the modern `@google/genai` TypeScript SDK.
- **Payments:** PayPal REST APIs (Sandbox Checkout).
- **Design:** Dark navy fintech palette (`#020617` / `#0f172a`), purple/indigo glows, emerald positive indicators.

---

## ⚙️ Environment Variables

Create or configure these variables in `.env` (or via the AI Studio Secrets panel):

```env
# Required for Gemini AI Financial Assistant & Shopping Reasoning
GEMINI_API_KEY="your-gemini-api-key"

# Host URL for self-referential links and PayPal return/cancel endpoints
APP_URL="https://your-app-domain"

# Optional: PayPal Sandbox Credentials for live Sandbox Order creation and capture
PAYPAL_CLIENT_ID="your-paypal-sandbox-client-id"
PAYPAL_CLIENT_SECRET="your-paypal-sandbox-client-secret"
PAYPAL_ENVIRONMENT="sandbox"
```

---

## 🏃 Getting Started

### 1. Installation
```bash
npm install
```

### 2. Running in Development
The dev server launches the unified full-stack Node.js Express server with Vite middleware on port 3000:
```bash
npm run dev
```

### 3. Building for Production
```bash
npm run build
npm start
```

---

## 🧪 Testing Checklist

- [x] **Gemini Integration:** Assistant answers questions referencing live transactions and expenses.
- [x] **Missing Parameter Handling:** Gemini asks clarifying follow-ups when key details are absent.
- [x] **Deterministic Arithmetic:** Purchase Intelligence outputs mathematically verifiable numbers for shortfalls, cash surplus, and emergency buffers.
- [x] **Catalog Integrity:** Smart Shopping specs and prices match authentic manufacturer specsheets.
- [x] **PayPal Order Validation:** Server rejects mismatched prices and validates order units against server catalog.
- [x] **Explicit Approval:** Zero automated billing; requires user action before payment capture.
- [x] **Responsive Mobile Layout:** Navigation drawer and tables adapt to mobile, tablet, and desktop screens.
- [x] **No Secrets in Bundles:** `GEMINI_API_KEY` and `PAYPAL_CLIENT_SECRET` are strictly kept server-side.

---

## 🔒 Security & Privacy

1. **No Bank Password Requests:** PayPilot AI never requests bank passwords, debit PINs, or CVV numbers.
2. **Deterministic Trust:** Authoritative balances are never computed by generative models.
3. **Transparent Demonstrations:** Synthetic demonstration records are visibly tagged with `[Demo]` badges.
