# Harambee — group trips where nobody fronts the money

**A little agreement. A great escape.** *Harambee* means “all pull together” in Swahili.

**The problem:** one friend puts the $600 cabin on their card, then spends weeks chasing everyone for their share. Their card carries the whole group's risk: if someone drops out or never pays, the organizer eats it.
**Why it matters:** in 2017 Airbnb reported that an estimated 38% of guests hadn’t received all the money owed to them from group trips ([VentureBeat](https://venturebeat.com/ai/airbnb-now-lets-groups-of-guests-split-the-cost-of-their-stay)), and in 2024 PayPal relaunched money pools for group trips and gifts, citing customer demand ([TechCrunch](https://techcrunch.com/2024/11/19/paypal-revives-its-money-pooling-feature/)).
**Who it’s for:** groups of 3–8 friends booking a shared stay, and the cabin operators who take their direct bookings.
**What changes:** nobody fronts the money. Each friend's own share is held in PayPal for the stay, so the organizer's card is never the one on the line. If someone drops out before booking, their hold is released and the rest of the group re-approves a new split, each authorizing only the difference; nobody pays more without saying yes again. After booking, the cabin's own cancellation policy applies to each person's own share.

> **Try the full journey in 3 minutes:** `npm ci && npm run dev`, open http://127.0.0.1:5171, and follow the [demo walkthrough](#demo-walkthrough). The default demo runs immediately with simulated payments and a labelled local planner. Connect PayPal sandbox and model credentials to exercise the provider integrations.

**Built and demonstrated:** separate-buyer PayPal sandbox approvals, dropout voids, exact-difference top-ups, a $600 booking capture, and a separate $600 group refund. AI proposes revised plans from chat; code verifies the details and each person approves their own share.

**How it works:**

1. Each friend approves their own exact share with a **PayPal authorization**. It is a hold, not a charge, and nobody is charged until everyone is in.
2. When someone drops out, their hold is voided. The group’s chat becomes **verified revision options**: a model proposes, and code checks every quote and computes every share. A limit like “I can’t go above $170” only counts once that person confirms it.
3. Everyone approves the new version. Earlier approval never covers an increase, so each person authorizes only the difference in their own PayPal checkout. Then Harambee captures and books.

Holds are collected within a 48-hour window and captured as soon as the group books, inside PayPal’s 3-day honor period for authorizations (an authorization stays valid for 29 days and can be reauthorized; see [PayPal: authorization](https://developer.paypal.com/docs/checkout/standard/customize/authorization/)).

## Demonstrated end to end

| Capability | Evidence |
| --- | --- |
| Separate buyers approve their shares, a dropout releases a hold, and the group books with exact-difference top-ups | [Recorded PayPal sandbox booking](docs/evidence/2026-10-04-sandbox-booking/README.md): three buyers, two $100 top-ups, $600 captured |
| Booking failure returns each person's money | [Recorded group refund](docs/evidence/2026-10-08-sandbox-group-refund/README.md): three $200 captures refunded, independently confirmed through PayPal |
| Versioned consent, payment recovery and source-grounded planning | 185 automated tests, a 28-case notes benchmark, 26 revision fixtures and a 16-scenario offline PayPal matrix |
| AI turns chat into options, source-linked reasons and questions | In the October 13 frozen run on 16 briefs written without seeing our fixtures, gpt-4.1-mini plus code checks passed 10/16, against 6/16 for a rules comparator. [Results and methodology](docs/REVISION_OPTIONS.md) |

**Demo setup:** PayPal sandbox uses test funds; cabin availability and reservations use local sample inventory. The default credential-free mode uses simulated payments and a local planner. Provider evidence identifies the source and configuration used in each run.

![After Sam leaves: a live gpt-4.1-mini option for $170 / $215 / $215 with quoted reasons, Maya confirming her $170 limit on her phone, and Jordan approving only the extra $65](docs/preview.png)

*Captured on October 13, 2026 from that day’s build with a live gpt-4.1-mini run and simulated payments. The PayPal sandbox runs are in [Demonstrated end to end](#demonstrated-end-to-end).*

## How this differs

Harambee focuses on the moment a committed group changes: a revised plan, fresh consent and an exact-difference approval. The October 2026 comparison below places that workflow alongside published group-payment approaches.

| What exists | What it does | Harambee’s implementation |
| --- | --- | --- |
| “Nobody pays until everyone pays” group checkout ([PayByGroup, 2012](https://techcrunch.com/2012/09/25/no-more-awkward-you-owe-me-money-reminders-paybygroup-lets-friends-split-group-purchases)) and tipping-point collection ([Crowdtilt/Tilt](https://en.wikipedia.org/wiki/Tilt.com), acquired by Airbnb in 2017) | Each person commits a share; nobody is charged unless the whole amount is reached. PayByGroup also let percentages change as more people joined | Harambee carries the commitment workflow through a group change: a new version, fresh consent from everyone, and only the difference authorized |
| Commit-now, pay-later group funds ([TableCash, September 2026](https://www.wboc.com/online_features/press_releases/tablecash-launches-commit-now-pay-later-for-group-plans-friends-put-a-card-down-up/article_8bd46577-9275-532c-b7ae-25630e5e5648.html), company press release) | Each person saves a card behind their share for a house or cabin; cards are charged together when the goal fills, and promises can be withdrawn before then. Money goes to the organizer through Stripe | The closest current product. Harambee's holds go to the merchant rather than an organizer, and after a dropout nobody's earlier promise stretches to a higher share |
| Split a bill after checkout ([PayPal help center](https://www.paypal.com/us/cshelp/article/how-do-i-split-a-bill-using-paypal-help279), in the PayPal account and on some partner sites such as Fandango) | The payer checks out first, then sends each friend a money request to pay them back | Nobody checks out for the group; each friend’s own PayPal holds their own share until everyone is in |
| Split payment at booking ([Airbnb, 2017](https://thepointsguy.com/news/airbnb-launches-split-payments/), retired around 2018 according to [hosts on Airbnb’s community forum](https://community.withairbnb.com/t5/Help/Split-payment-option-is-no-longer-available-disappointing/m-p/529891); Airbnb hasn’t published why; [Wander “Split with Friends”, 2025](https://wander.com/article/introducing-split-with-friends-an-industry-first)) | The organizer pays their part; the booking is held while others pay within a window (72 hours at Airbnb, after which it was forfeited and refunded; 48 hours at Wander) | Holds instead of charges for everyone, including the organizer, and a plan that can change after someone leaves |
| Group split for direct-booking rentals ([StretchBill GroupPay](https://www.ownerrez.com/blog/integration-with-stretchbill), listed in the OwnerRez and Hostaway marketplaces; [Guesty](https://help.guesty.com/hc/en-gb/articles/20548335510173-Splitting-a-payment) multi-guest payments) | The property manager splits one reservation's payment among the group's guests | Each share is an authorization rather than a charge, and when someone leaves, everyone re-approves and authorizes only the difference |
| Merchant group checkout ([Hands In API workflow](https://www.handsin.com/blog-posts/how-do-our-api-payments-work), 2024, vendor documentation) | Each member authorizes their share; payments are captured directly to the merchant. When shares change after a dropout, its [FAQ](https://www.handsin.com/frequently-asked-questions?7641a557_page=2) describes voiding affected authorizations and asking those members to approve their new amounts | Harambee binds approval to a specific plan version: after a dropout, everyone remaining approves the revised plan and each increase receives a separate exact-difference checkout ([why the difference](#why-approve-only-the-difference)) |
| Group collection ([PayPal pools](https://techcrunch.com/2024/11/19/paypal-revives-its-money-pooling-feature/), [Cash App Pools](https://cash.app/press/cash-app-launches-pools-for-group-payments) (July 2025, limited rollout), [Venmo Groups](https://techcrunch.com/2023/11/14/venmo-gets-a-new-way-to-split-expenses-among-groups-like-clubs-teams-trip-buddies-and-more), Splitwise) | Collects or tracks money owed to one person | Each friend’s authorization goes to the merchant; nobody acts as the group’s bank |
| AI trip planners with group chat ([Mindtrip](https://globetrender.com/2024/09/24/mindtrip-launches-group-chat-feature/)) | Turn shared preferences into an itinerary | Turn a dropout into price options that are checked by code and re-approved by each person |
| **Harambee’s focus** | | When the group changes, a new version needs fresh consent from everyone remaining, and each person authorizes only the difference. Earlier approval never covers an increase. |

Harambee brings versioned agreement into the payment flow. When a group changes after commitment, each remaining person approves the revised plan and authorizes only the difference. Limits read from chat count once their owner confirms them. This connects planning, personal consent and payment recovery in one journey.

That is deliberately stricter than PayPal's own rules. PayPal lets a merchant capture more than was authorized, up to 115% of the authorization or $75 more, whichever is less ([PayPal: authorize and capture](https://developer.paypal.com/docs/multiparty/checkout/standard/customize/auth-capture/)). Harambee never does: a larger share is always a new checkout for the difference, approved by that person.

### Why approve only the difference

The alternative is to void a person's hold and ask them to authorize the full new share (as Hands In's FAQ describes), or to reauthorize within PayPal's limits. Harambee instead leaves the earlier hold in place and opens a second checkout for the extra amount only:

- **The earlier hold is never put at risk.** An abandoned or declined top-up leaves the original authorization untouched, so the organizer can still publish another option. Holds are voided only when a share goes down or the cabin changes. With void-and-reauthorize, a friend who doesn't finish the new checkout leaves the group with no hold at all.
- **People approve only new money.** The checkout shows “+$65”, not a fresh $215 that looks like a second charge.
- **The cost is an extra capture per increase.** The [October 4 booking](docs/evidence/2026-10-04-sandbox-booking/README.md) captured $600 in four captures instead of two, and each capture can carry a per-transaction fee. An operator with tight margins and reliable groups might prefer void-and-reauthorize; the [operator pilot](docs/OPERATOR_PILOT.md) compares the costs.

## Who is the merchant, and who pays

The cabin operator is the merchant. In a real deployment, each friend’s authorization would be made to the operator’s own PayPal business account, so Harambee never holds or moves the group’s money. PayPal supports this for platforms through its [multiparty](https://developer.paypal.com/docs/multiparty/) integration. For authorize-then-capture, the order and the authorization name the seller as `payee` ([multiparty authorize and capture](https://developer.paypal.com/docs/multiparty/checkout/standard/customize/auth-capture/)). That page requires an approved PayPal partner, sellers onboarded first, and the `PARTNER_FEE` onboarding feature for a platform fee. (PayPal's multiseller page requires `intent: CAPTURE`, so it doesn't fit a hold-first design.) The demo sends captures to its sandbox merchant account; operator routing is part of the platform rollout.

Rollout model:

- Start with direct-booking operators whose stays can be funded by several authorizations before committing dates.
- Quote a disclosed platform fee before participants approve their shares.
- Define processing and recovery costs in the operator agreement before enabling bookings.

**Initial customer segment:** independent cabin and glamping operators with their own booking site who already accept PayPal, reached the way StretchBill reaches them: as an app in the property-management marketplaces they already use. The rollout starts with operator onboarding, inventory timing and a clear fee model. The size of this segment is a hypothesis we haven't measured; the [operator pilot](docs/OPERATOR_PILOT.md) is how we'd test it.

**Hypothetical operator example:** a direct-booking cabin quotes $600 for four friends and permits a 48-hour collection window. Each approves a $150 hold. One leaves before booking, so that hold is released; the remaining friends choose $170 / $215 / $215, and approve only $20 / $65 / $65 more. The operator commits the dates only when the current agreement can be funded; an unavailable stay leads to release/refund rather than a completed reservation. The demo exercises this with sample inventory.

For an initial operator agreement, the proposed responsibilities are: the operator owns availability and cancellation terms and covers its payment-processing costs; Harambee supplies agreement tracking and reconciliation; any platform fee is disclosed in the quote before approvals. Refund/support costs and the inventory hold window are agreed before onboarding. The [operator pilot plan](docs/OPERATOR_PILOT.md) defines the inventory window, cost responsibilities and a comparison with the operator’s current checkout. It will measure completed direct group bookings, support effort and recovery costs.


**Lessons from earlier group-payment products:**

- Airbnb's 2017 split payments charged the organizer's share and held the booking for 72 hours while everyone else paid; if anyone didn't, the reservation was forfeited and everyone refunded ([The Points Guy](https://thepointsguy.com/news/airbnb-launches-split-payments/)). It had no way to re-split when someone left. Harambee keeps every share as a hold, including the organizer's, and lets the remaining group re-approve a new split.
- Tilt was acquired by Airbnb and shut down in 2017 ([Wikipedia](https://en.wikipedia.org/wiki/Tilt.com)), so its end says little about demand.
- Collection apps (pools, TableCash) route money to the organizer, which makes the organizer the group's bank again. Harambee's authorizations go to the merchant.

The comparison describes published workflows; Harambee’s column documents its implemented version-bound agreement and exact-difference approval.

## Run locally

Requires Node.js 22+ and npm. No credentials are needed for the default demo.

```sh
npm ci
npm run dev
```

Open [Harambee](http://127.0.0.1:5171). Vite serves the UI on port 5171 and proxies API requests to port 3101. The backend does not auto-restart when you edit server files; restart `npm run dev` after backend changes. Frontend updates reload automatically.

For one local production server:

```sh
npm run build
npm start
```

Open [the production build](http://127.0.0.1:3101). Do not run the dev and production backend simultaneously. `PORT`, `HOST`, and `DATA_FILE` can override local defaults; Vite's API proxy expects port 3101.

```sh
npm test
```

The native Node test suite covers exact allocations, private budget projection, role checks, stale version rejection, explicit top-ups, duplicate operations, deadlines, cabin capacity, restart persistence, capture failures and timeouts, refunds pending confirmation, merchant failures, and sandbox adapter contracts. GitHub Actions runs tests and a production build.

For the additional 16-scenario payment matrix, strict checks of known failures, and isolated $1 PayPal sandbox recovery tests, see [Sandbox testing](docs/SANDBOX_TESTING.md). The [October 8 run](docs/evidence/2026-10-08-offline-sandbox-matrix/README.md) passes all sixteen scenarios; the two amount/currency failures recorded on October 7 are fixed.

For filming-day preparation, see [the three-run rehearsal command](docs/FILMING_PREFLIGHT.md).

For module ownership, test seams and proposal adapters, see the [implementation map](docs/ARCHITECTURE.md).

## Demo walkthrough

1. Start with four friends and the $600 Pine & Still cabin. Click **Review** beside each person, review their saved private $220 ceiling (use **Save budget only** for edits), and select **Agree & authorize simulated hold**. The demo role switch intentionally lets one judge act as each participant.
2. Switch to Organizer. Withdraw Sam using the exit icon. Their hold is voided, and the plan requires a revision.
3. Choose **Suggest options**. Harambee reads the group chat pasted into **Planning notes**. In the sample chat Sam leaves, Maya says she “can’t go above $170” now, and Alex prefers the cheaper cabin. Code computes every share and top-up for the verified options, and each AI option lists the chat lines behind it. Maya’s $170 option waits for her: choose **Send Maya a confirmation request**, then open Maya’s view (**Demo controls → Open Maya’s view**) and confirm there. The organizer’s card updates by itself. The plain rebalance ($200 each) and the cheaper cabin ($160 each) are also offered; an option that produces exactly the same split as another is shown once. See [Revision options](#revision-options-after-a-dropout).
4. Publish an option. Each remaining friend explicitly approves the new version and their exact top-up. The original version never grants permission for an increase.
5. Return to Organizer and book. The system locks the plan, captures each simulated payment, and commits local inventory. Open **Activity & receipts** or export the JSON evidence.
6. Reset and approve the group again. Under **Demo scenarios**, choose a capture failure or timeout before booking. The board says in plain words why booking stopped, whose payment failed, and what will be returned. **Return money & release holds** checks each payment with the provider, refunds confirmed captures, voids unused holds, and releases inventory. The pending-refund scenario requires a second recovery pass; it cannot falsely report completion.
7. If nobody's limits can cover any cabin (withdraw two people), the options say so and offer **Cancel trip & release every hold**.
8. For the constrained-budget case, set one remaining person's ceiling to $170 during review, then republish the allocation as Organizer. The deterministic split is $170/$215/$215. **View allocation details** also offers the $480 alternative; a changed cabin requires new consent.

New trips accept three to eight distinct names and a fixed fixture stay on November 6–8, 2026. Creekside has capacity for six, Pine & Still for eight. Unknown ceilings require participant confirmation before approval. The demo allows two people to remain after a withdrawal.

## Optional AI interpretation

```sh
cp .env.example .env
```

Set `OPENAI_API_KEY` and optionally `OPENAI_MODEL`, then restart. In **Planning notes**, choose **Find the preferences**. The server uses the OpenAI Responses API with a strict structured-output schema, a 12-second timeout, exact source-quote validation, and bounded input/output. Model credentials never reach the browser. No model receives payment tools.

Without a key, or if the model times out or returns unverified content, the app explicitly uses a **local parser**. That fallback is not an AI model. Both paths produce reviewable drafts only: they cannot change budgets, consents, amounts, or payment states. Notes and interpretations are not persisted; they remain in browser memory until reload. If the model is enabled, submitted text is sent to its provider with `store: false`. Do not submit unconsented personal conversations. Latency and token usage are displayed for model responses; provider cost is not calculated. Source-linked drafts now check extracted amounts and names against conservative line-level USD grounding. Contradictions lose their numeric suggestion; discrepant model fields are replaced by source-grounded values and explicitly flagged. Each draft can open a participant review with the source visible; applying a suggestion to the field, saving a budget, and approving a share remain separate actions.

Run `npm run eval` for the 28-case parser/verifier benchmark: synthetic labeled inputs and three injected model-output mistakes. [`eval/results.json`](eval/results.json) records the results. `npm run eval:live -- --write` runs the optional notes-interpreter benchmark against the configured provider; the committed live benchmarks below evaluate revision options.

Reference: [OpenAI Structured Outputs](https://developers.openai.com/api/docs/guides/structured-outputs).

## Revision options after a dropout

When someone leaves, the organizer chooses **Suggest options**. A model (gpt-4.1-mini) reads the group chat and proposes up to three options, each with its reasons quoted from people's own messages. Code checks every quote, amount and speaker, computes every share, and shows the plain rebalance alongside. A limit read from chat counts only after its owner confirms it in their own view, and the model never sees anyone's saved budget. Without a key, a labelled **local planner (not AI)** keeps the flow working.

Recorded on October 13, 2026 at commit `31589b9`; each result file carries its source hashes:

| Test | gpt-4.1-mini + code checks | Without the model |
| --- | --- | --- |
| [16 independent briefs with no amount](docs/REVISION_OPTIONS.md#independent-briefs) | 10/16; asked 8 of the 11 needed questions, all to the right person | Rules comparator: 6/16 (4 of 11). Local planner: 0/16 |
| 26 synthetic briefs with amounts | 25/26 useful; 24/26 from the model alone. Earlier rounds: 24–26/26 | Local planner: 23/26 |
| 10 no-amount development briefs | 8/10; the model asked 1 of 6 needed questions, code 4 more | Rules written for these briefs: 10/10. Local planner: 2/10 |
| The demo's sample chat, 3 runs | Maya's $170 / $215 / $215 card in 2 of 3; in the third, code asks Maya to confirm $170 | Local planner: same card and confirmation |

The independent briefs were written by a separate AI agent that saw none of our fixtures or code, not by a person; [details](eval/revision-cases-independent.README.md). Every publishable option stayed within saved budgets, which holds by construction. Publishing always recomputes from participant-confirmed budgets. The benchmark uses fixed synthetic briefs, with each provider run recorded separately.

**[How options are checked, privacy, the ambiguity backstop, recorded provider runs and benchmark design →](docs/REVISION_OPTIONS.md)**

## Integrated PayPal sandbox group

1. Configure sandbox merchant credentials in `.env`, run `npm run paypal:check` to confirm PayPal accepts them, restart, and start an unfunded trip with three distinct participants. Set each private ceiling to at least $300 for the $600 trip if demonstrating a dropout to two remaining buyers.
2. As Organizer open **Demo controls** and choose **Use PayPal sandbox for this group**. Participant links open separate tab-scoped views; they are local demo selectors, not authentication. Use distinct sandbox buyer accounts and separate browser profiles for their PayPal logins.
3. Each participant reviews the exact version/share, saves their budget separately, and approves. **Agree & open sandbox checkout** sends that buyer to PayPal in the same tab. After approval PayPal returns them to their participant view, which asks the server to authorize the order; **I approved in PayPal — confirm authorization** remains as a manual fallback. Server state validates the exact USD amount and unique buyer identity. Browser approval alone never counts as a hold. A buyer already holding another participant's share has the new hold voided and is asked to use a different sandbox account.
4. Withdraw one participant. Their actual sandbox authorization must be voided before the new version is published. Remaining participants explicitly approve the revised version and additional amount only, then complete their top-up checkouts. Original consent cannot authorize an increase.
5. Book once every exact current share is authorized. Provider captures run sequentially against persisted authorization IDs, followed by a **local fixture** reservation commit. Export the provider-labeled receipt evidence.
6. In a separate prepared trip select **Merchant commit fails** before booking to exercise compensating refunds. Reconcile until every refund/void is confirmed. An unknown operation remains blocked with investigation guidance; never create a replacement charge. If PayPal declines a capture, nothing was taken and the open hold is voided. If PayPal reports a refund as failed or cancelled, the board says so with PayPal's reason, and the refund is retried only when the organizer chooses **Retry the failed refund**, with a new request ID. An order nobody approved that PayPal no longer has is closed as abandoned. **Cancel trip** voids every hold the same way. Inspect sandbox activity if the provider cannot supply a recoverable ID.

`test/group-payments.test.mjs` verifies this integrated journey with mocked buyers/providers, restart between provider and coordinator saves, partial capture, unresolved capture, stale checkout, distinct buyers, and fixture-commit failure. The booking journey has also run against the real PayPal sandbox; see the [recorded evidence](docs/evidence/2026-10-04-sandbox-booking/README.md). The separate [October 8 group refund run](docs/evidence/2026-10-08-sandbox-group-refund/README.md) also verified three distinct buyers, $600 captured then fully refunded after a fixture reservation failure. The local demo uses a single backend process and polling reconciliation. The diagnostic lab cannot operate on group-linked sessions. Reset refuses unresolved sandbox money. After a confirmed booking it first archives the trip's provider evidence to `data/archive/`.

## Optional PayPal sandbox lab

Set `PAYPAL_CLIENT_ID` and `PAYPAL_CLIENT_SECRET` to a **sandbox** merchant application's credentials, restart, then open **PayPal sandbox lab** beneath the booking sidebar in Organizer view.

1. Create a sandbox order between $1 and $500.
2. Open the generated PayPal approval link and approve using a separate sandbox buyer account.
3. Return and confirm authorization. Server-side provider state is authoritative; browser approval alone does not mark it authorized.
4. Capture the displayed exact test amount, or void the unused authorization.
5. Refund a captured payment, and reconcile pending or unknown results.

The adapter is pinned to `https://api-m.sandbox.paypal.com`; there is no live profile. It persists operation IDs before dispatch, uses `PayPal-Request-Id`, separates authorization/capture/refund statuses, and serializes each lab session. Timeouts become unknown. Reconciliation queries PayPal; an unknown order or capture without a recoverable provider ID requires inspection in the sandbox dashboard and is never automatically recharged. The default demo reset does not delete sandbox operation evidence.

This diagnostic lab is a **single-payment workflow**, separate from the integrated group path above. Its real sandbox [October 8 recovery run](docs/evidence/2026-10-08-paypal-recovery/README.md) captured and refunded $1, voided a separate $1 hold, and recovered both after successful responses were deliberately discarded. All 12 checkpoints passed. The lab reconstructed its state from disk; recovery sent no duplicate refund or void. An optional webhook route (`POST /api/paypal/webhook`, enabled by `PAYPAL_WEBHOOK_ID`) verifies each delivery with PayPal's signature-verification API and then runs the same reconcile; it never trusts the event's status. It is unit-tested only: no live sandbox delivery has been recorded yet, so polling remains the tested path.

References: [PayPal delayed capture](https://developer.paypal.com/checkout/delay-capture/), [Payments v2](https://developer.paypal.com/docs/api/payments/v2/), [Orders v2](https://developer.paypal.com/docs/api/orders/v2/).

## Implementation

- React + Vite frontend with responsive desktop/mobile layouts, keyboard-operable native dialogs, labeled inputs, visible focus, and reduced-motion support.
- Node HTTP backend; integer-cent deterministic capped allocation; versioned consent and independent agreement/payment states.
- Atomic JSON snapshots in `data/plan.json`; a separate `data/sandbox-lab.json` retains sandbox evidence. Each simulator operation has a unique stable key and is stored before its confirmed result.
- A single backend process serializes all mutation requests, including asynchronous provider calls; production scaling adds transactional storage and cross-process coordination.
- The booking coordinator stops after a failed/unknown capture. It reconciles uncertainty before refunding captures and voiding unused holds. A merchant commit timeout can reconcile to confirmed without repeating captures.
- Deadlines sweep on startup, on API access, and every 30 seconds while the process runs. Expired simulated holds are voided and late approvals rejected. Sandbox expiry runs the asynchronous provider recovery path; uncertainty keeps recovery open.
- Demo roles are checked at API actions; budgets are projected only to their participant identity. **Run the participant selector locally:** it is a demo control. Deployment requires authenticated identities and session authorization.

## Demo environment and roadmap

The demo runs one trip at a time with fixed sample stays and a visible participant selector. It uses simulated payments by default and real PayPal sandbox calls when credentials are configured. Sandbox booking and three-buyer refund records are linked above.

Production rollout adds authenticated participant invitations, transactional storage, operator onboarding and inventory (an optional `PAYPAL_PAYEE_EMAIL` sets an operator payee on each order but hasn't been tried in sandbox; PayPal may require partner approval for it), a recorded live webhook delivery, background reconciliation, and retention controls. The local server binds to loopback and accepts local browser origins. Cabin art is inline SVG; optional Google Fonts have system-font fallbacks.

Use synthetic data. Demo reset clears the simulated trip's stored record. The pasted group chat itself is never saved; it stays in browser memory, and the server keeps it only in memory while options are open. One exception: when the organizer sends a limit request, up to 200 characters of that person's own message are saved with the request in `plan.json`, so their card can quote it. Only that person and the organizer can see it, and reset clears it. Local financial fixtures remain until reset/deletion, and sandbox audit records remain until explicitly removed after reconciliation. Do not delete unresolved sandbox evidence.

See [PRD.md](PRD.md) for the product plan and [SHARED_REQUIREMENTS.md](SHARED_REQUIREMENTS.md) for submission requirements.

MIT licensed. Source: [github.com/Jeremiah-Sakuda/harambee](https://github.com/Jeremiah-Sakuda/harambee).
