# Panjar

Ubah chat WhatsApp dari turis asing menjadi **invoice deposit PayPal** dengan aturan batal otomatis, pengingat, dan pelunasan H-1. Untuk sopir, pemandu, dan pemilik villa kecil di Indonesia. Aplikasi **tidak pernah memegang dana**; semua pembayaran terjadi di PayPal (sandbox selama hackathon).

```
tempel chat → draf booking (Claude) → tinjau & gross-up → kirim invoice (Agent Toolkit)
→ turis bayar di PayPal → webhook PAID → kalender terisi → pelunasan H-1 / bayar tunai
```

## Setup

```bash
npm install
cp .env.example .env   # isi kunci (lihat di bawah)
npm run dev            # http://localhost:3000
```

Isi `.env`:

| Variabel | Keterangan |
|---|---|
| `PANJAR_MODE` | `mock` (tanpa PayPal, invoice disimulasikan, halaman bayar tiruan di `/mock/pay/<id>`) atau `sandbox` |
| `PAYPAL_CLIENT_ID`, `PAYPAL_CLIENT_SECRET` | Aplikasi sandbox dari developer.paypal.com |
| `PAYPAL_WEBHOOK_ID` | Webhook sandbox untuk event `INVOICING.INVOICE.PAID`, URL `https://<host>/api/webhooks/paypal` |
| `ANTHROPIC_API_KEY` | Kunci Claude. Kosong = ekstraksi heuristik offline (hanya untuk dev) |
| `PANJAR_MODEL` | Default `claude-opus-5-5` |
| `OPERATOR_NAME`, `OPERATOR_BUSINESS`, `OPERATOR_EMAIL` | Identitas penagih di invoice |
| `PANJAR_ACCESS_KEY` | Opsional: kunci HTTP Basic untuk UI operator (user bebas, password = kunci) |
| `CRON_SECRET` | Opsional: Bearer token untuk `/api/cron/tick` |
| `KURS_USD_IDR`, `KURS_SUMBER` | Kurs referensi untuk estimasi rupiah (tampilan saja) |
| `DEPOSIT_PERSEN_DEFAULT`, `DEPOSIT_TENGGAT_HARI` | Default 30% dan H-2 |

Tanpa kunci apa pun, aplikasi langsung jalan dalam mode mock: cukup untuk melihat seluruh alur dan menjalankan E2E.

## Pemeriksaan

```bash
npm test            # Vitest: gross-up, ekstraksi, klasifikasi, booking, scheduler, webhook
npm run typecheck
npm run test:e2e    # Playwright, mode mock: chat → invoice → bayar → webhook → kalender (+ kasus negatif)
npm run spike       # sandbox nyata: create_invoice → conditional rules → send → get (butuh kunci PayPal)
```

## Cara demo (sandbox)

1. `PANJAR_MODE=sandbox`, isi kunci PayPal dan Anthropic, deploy ke URL publik (Render) atau buka tunnel lokal.
2. Di dashboard PayPal sandbox, daftarkan webhook `https://<host>/api/webhooks/paypal` untuk event `INVOICING.INVOICE.PAID`; salin ID-nya ke `PAYPAL_WEBHOOK_ID`.
3. Buka aplikasi, klik **Isi contoh**, **Buat draf booking**, ganti email turis dengan email akun pembeli sandbox, **Kirim invoice deposit**.
4. Masuk sebagai pembeli sandbox, buka email/URL invoice, bayar.
5. **Booking & kalender**: tanggal terisi hijau begitu webhook masuk. Tombol **Jalankan pemeriksaan harian** menjalankan pengingat, batal fallback, dan pelunasan H-1 (di produksi: Render Cron Job memanggil `GET /api/cron/tick` tiap pagi).

Skrip video 3 menit: [docs/DEMO.md](docs/DEMO.md). Teks pengumpulan dan batasan jujur: [docs/SUBMISSION.md](docs/SUBMISSION.md).

## Arsitektur

Satu aplikasi Next.js (App Router). `lib/` berisi logika yang diuji unit; `app/api/` route handler tipis.

| Modul | Tugas |
|---|---|
| `lib/extract.ts` | FR1: chat → draf (Claude + Zod; field absen = null). Heuristik offline bila tanpa kunci |
| `lib/grossup.ts` | FR3: `(net / 0,956 + 0,30) / 0,97`; $100 bersih → $104,90 → $108,14 |
| `lib/paypal/toolkit.ts` | FR4/FR7/FR8: @paypal/agent-toolkit (`create_invoice`, `create_conditional_rules_for_invoice`, `send_invoice`, `get_invoice`, `send_invoice_reminder`, `cancel_sent_invoice`, `record_payment_for_invoice`) |
| `lib/paypal/mock.ts` | Gateway tiruan untuk dev/E2E |
| `lib/webhook.ts` | FR5: verifikasi tanda tangan, idempoten, hanya `INVOICING.INVOICE.PAID` mengubah status |
| `lib/scheduler.ts` | FR7 fallback (pengingat, batal setelah tenggat) dan FR8 (pelunasan H-1), sinkron status |
| `lib/classify.ts` | FR9: ubah/batal/lain → usulan; eksekusi hanya lewat `step: "approve"` |
| `app/bookings` | FR6: kalender dan daftar booking |

Status booking: `tentatif → deposit_lunas → pelunasan_terkirim → lunas`, atau `batal`.

## Keputusan dan batasan

- **Agent Toolkit dipanggil langsung, bukan lewat LLM.** Urutan create → rules → send bersifat deterministik dan harus bisa diuji; LLM dipakai untuk bagian yang memang butuh bahasa (ekstraksi, klasifikasi). Tool yang dipakai tetap tool resmi `@paypal/agent-toolkit/ai-sdk`.
- **Aturan bersyarat** dicoba di setiap pengiriman; bila sandbox menolak, invoice tetap terkirim dan dicatat `fallback`, lalu cron menjalankan pengingat dan pembatalan. `npm run spike` menjawab pertanyaan ini untuk akun sandbox kamu.
- **Database** SQLite lewat Drizzle (`DATABASE_PATH`); di Render pakai persistent disk. Migrasi ke Postgres: ganti `lib/db/client.ts` dan dialek skema.
- **Refund (FR10), WhatsApp Business API (FR11), multi-operator (FR12)** ditunda.
- **Kepatuhan:** invoice USD untuk pembayar asing; UU 7/2011 (kewajiban rupiah) belum dicek ke teks UU. Aplikasi tidak memegang dana.

## Deploy ke Render

Konfigurasi ada di [render.yaml](render.yaml) (Blueprint): web service Node (`npm install && npm run build`, `npm start`), persistent disk 1 GB di `/data` dengan `DATABASE_PATH=/data/panjar.db`, `PANJAR_MODE=sandbox`, dan cron job harian pukul 00:00 UTC (07:00 WIB) yang memanggil `GET /api/cron/tick` dengan `Authorization: Bearer $CRON_SECRET`.

1. Render dashboard → **New → Blueprint** → pilih repo ini → **Apply**.
2. Isi variabel yang diminta: `PAYPAL_CLIENT_ID`, `PAYPAL_CLIENT_SECRET`, `ANTHROPIC_API_KEY`, `PANJAR_ACCESS_KEY`, dan `NEXT_PUBLIC_APP_URL=https://<nama-service>.onrender.com`. `CRON_SECRET` dibuat otomatis dan dibagikan ke cron job. `PAYPAL_WEBHOOK_ID` boleh dikosongkan dulu.
3. Setelah service hidup, daftarkan webhook `https://<host>/api/webhooks/paypal` (event `INVOICING.INVOICE.PAID`) di dashboard PayPal sandbox, salin ID-nya ke `PAYPAL_WEBHOOK_ID`, lalu **Manual Deploy**.

Persistent disk membutuhkan instance berbayar (plan `starter`); tanpa disk, database SQLite hilang tiap deploy.

Lisensi MIT.
