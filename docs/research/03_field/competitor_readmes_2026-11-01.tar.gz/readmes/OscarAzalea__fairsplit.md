# FairSplit ⚡
> **PayPal AI Hackathon 2026 Submission**  
> *The Trust-Chained Rev-Share Protocol for Creative Collectives & Indie Game Studios*\n\n[![Automated Tests](https://img.shields.io/badge/Tests-11%2F11%20Passing-emerald)](./tests/fairsplit.test.ts)\n[![Hosted Demo](https://img.shields.io/badge/Demo-Cloudflare%20Worker-blue)](https://fairsplit.horusosiris404-210.workers.dev)\n\n🌐 **Live Hosted Demo (Cloudflare Worker):** [https://fairsplit.horusosiris404-210.workers.dev](https://fairsplit.horusosiris404-210.workers.dev)

---

## 🎮 What is FairSplit?
**FairSplit** is a fintech web application engineered for collaborative creative teams (such as indie game studios and music co-ops) operating under shared revenue agreements.

In collaborative projects like indie game **"Project Aurora"**, equity disputes, spreadsheet calculation drift, unrecorded retroactive split shifts, and opaque payout lump sums frequently jeopardize release schedules and trust.

FairSplit resolves this through 4 foundational pillars:
1. **Deterministic Fintech Math in Integer Cents**: Zero floating-point errors (`0.1 + 0.2` drift eliminated). Hamilton-Hare Largest Remainder Method ensures exact penny distribution where `sum(shares) === netInflow` always.
2. **Agreement Studio**: 4-member rev-share (*Dev 40%, Artist 30%, Writer 20%, Composer 10%*). Interactive dials and direct percentage entry, Gemini-powered **Socratic AI Negotiation Drawer**, and a four-member demo approval flow.
3. **Trust Ledger**: SHA-256 linked agreement records (`v1.0` &rarr; `v2.0`) in the current browser session. Each inflow records the active agreement hash. The integrity check detects changes to these in-memory records; it cannot identify who changed them or provide immutable storage.
4. **Payments Hub**:
   - **Inflows**: With PayPal Sandbox credentials, buyers approve a real Sandbox order before the server captures it. Without credentials, FairSplit uses an explicitly labelled local simulator.
   - **Outflows**: Builds a Payouts API batch preview and simulates its result. No payout funds are sent.
5. **AI assistance**: Gemini powers negotiation and balance explanations when configured and available. A local heuristic fallback keeps the demo usable without a key or during API errors. Proposed splits are checked to total exactly 10,000 basis points, and people still ratify agreements.

---

## 🚀 Quick Start

### 1. Install Dependencies
```bash
npm install
```

### 2. Configure integrations (optional)
Copy .env.example to .env.local.

- For PayPal Sandbox checkout, set both PAYPAL_CLIENT_ID and PAYPAL_CLIENT_SECRET from a Sandbox REST app. Use a Sandbox personal buyer account to approve the order.
- For Gemini, set GEMINI_API_KEY. Without it, AI tools use the local heuristic.
- Payout batches are simulated in this version, even when PayPal checkout is configured.

### 3. Run the Development Server
```bash
npm run dev
```
Open [http://localhost:3000](http://localhost:3000) in your browser.

### 4. Build for Production
```bash
npm run build
npm run start
```

### Deploy to Cloudflare Workers

The repository includes the OpenNext adapter and Wrangler configuration for Cloudflare Workers.

```bash
npm run build:worker
npm run deploy:worker
```

In the Cloudflare dashboard, open **Workers & Pages → fairsplit → Settings → Variables and Secrets**. Add `PAYPAL_CLIENT_ID`, `PAYPAL_CLIENT_SECRET`, and `GEMINI_API_KEY` as **Secret** values, then deploy the changes. The first two enable PayPal Sandbox checkout; the third enables Gemini. Without them, the deployed app clearly identifies its checkout simulator and heuristic AI fallback. Keep these values out of Git and `wrangler.json`.

---

## 🧪 Hackathon Judging & Interactive Walkthrough

1. **Agreement Studio**:
   - Adjust any member's slider dial (e.g. raise Composer from 10% to 15%). Notice how the dials automatically rebalance the unlocked team members while preserving the exact 10,000 basis points (100.0%) total.
   - Click **"Socratic AI Mediator"** to open the Gemini negotiation drawer. Review the trade-off synthesis, Socratic probing questions, and consensus score.
   - Click **"Propose New Epoch"** to start the 4-party ratification flow. Sign individually or click **"Fast-Ratify All (Demo)"** to lock and activate Epoch `v2.0`!

2. **Trust Ledger (SHA-256)**:
   - Observe how the hash chain updates with block `v2.0` linked to `v1.0.hash`.
   - Click **"Check Epoch Hashes"** to recompute the current session's SHA-256 links.
   - Click **"Simulate Split Tamper"** to see a hash mismatch; the check cannot identify an actor.

3. **Payments Hub (Inflows & Outflows)**:
   - In the Inflows panel, select **"itch.io Direct ($49.99)"** or enter a custom amount.
   - Review the estimated fee and exact penny allocation table. A PayPal capture fee is used when PayPal returns one; otherwise FairSplit uses its displayed estimate.
   - With Sandbox credentials, approve the order in the PayPal Sandbox window and confirm the server-reported capture ID. Without credentials, run the clearly labelled local simulator.
   - In the Outflows panel, inspect the Payouts API payload, then click **"Simulate payout batch"**. No funds are sent by this demo.

4. **Collaborator Balances & AI Audit**:
   - Go to **Collaborator Balances** to see balances in cents and dollars. Existing inflows retain the split from their capture epoch.
   - After demo approval of a new split, the unpaid reserve is automatically redistributed under that split. The screen previews exact per-member amounts; historical inflow allocations and demo payout records remain visible. New inflows use the active split.
   - Use **Clear Demo Activity** to remove generated inflows and payout simulations. The active split remains applied to the remaining sample reserve.
   - Click **"Explain My Balance (AI)"** on any member (e.g. Alex the Dev or Lyra the Composer) to review the transparent, plain-English ledger audit generated by Gemini.

---

## 🛠️ Complete Project Specification
Read the full technical specification at [`FAIRSPLIT_SPEC.md`](./FAIRSPLIT_SPEC.md) located in the project root.

## 🎥 Demo recording
Use [`HACKATHON_DEMO.md`](./HACKATHON_DEMO.md) for a short judge walkthrough and recording checklist. The app's demo data is held in memory; use **Reset demo** in the status bar to restore the seeded example.

Hosted demo: [fairsplit-ai.netlify.app](https://fairsplit-ai.netlify.app). The repo is published under [MIT](./LICENSE). The hackathon submission also needs a public YouTube demo under three minutes; this repository does not contain that recording.

Primary Hosted Demo (Cloudflare Worker with live PayPal Sandbox and Gemini): [https://fairsplit.horusosiris404-210.workers.dev](https://fairsplit.horusosiris404-210.workers.dev). The Netlify deployment remains available during the migration.

Before claiming the workflow fits real teams, run a few sessions using [`USER_TEST_GUIDE.md`](./USER_TEST_GUIDE.md) and record actual participant feedback.

The automated accounting checks run with `npm test` on Node.js 24. Demo state automatically persists across browser reloads via localStorage; click **Reset Demo** in the top navigation to restore pristine Genesis defaults at any time.
